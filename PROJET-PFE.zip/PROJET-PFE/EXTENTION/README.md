# NovaX – Extension de protection phishing

Ce dépôt contient une extension de navigateur (Manifest V3) qui ajoute une couche de protection contre le phishing, avec un focus sur Gmail et Outlook (pour l'instant).  
L’objectif de ce document est d’expliquer l’architecture de l’extension de façon simple.

- ce que fait l’extension ;
- comment les fichiers sont organisés ;
- comment les différentes parties discutent entre elles ;
- pourquoi certains choix techniques ont été faits.

---

## Vue d’ensemble

L’extension fait essentiellement deux choses :

- Analyse des liens dans les pages web (emails, pages web, etc.) et affichage d’un tooltip de sécurité au survol d’un lien ;
- Affichage de statistiques globales (liens analysés, menaces détectées) dans le popup de l’extension.

Pour fonctionner, elle s’appuie sur :

- un content script injecté dans les pages (fichier `content.js`) ;
- un service worker de fond qui gère la logique centrale et les statistiques (fichier `background.js`) ;
- une interface utilisateur popup (fichiers `popup.html` et `popup.js`) ;
- une petite API locale de test (fichier `server.js`) qui simule un backend d’analyse.

Le tout est déclaré et assemblé via le fichier `manifest.json`.

---

## Structure du projet

À la racine du projet :

- `manifest.json` : configuration de l’extension (permissions, scripts, popup, etc.).
- `background.js` : service worker de fond (logique centrale et stats).
- `content.js` : script injecté dans les pages pour intercepter les liens et afficher le tooltip.
- `popup.html` / `popup.js` : interface popup de l’extension.
- `server.js` / `package.json` : serveur HTTP local qui simule une API d’analyse des liens.
- `icons/logo_novaX.png` : icône utilisée par l’extension.

---

## Rôle de chaque composant

### 1. `manifest.json`

Le `manifest.json` est le point d’entrée d’une extension Chrome.

Principales sections :

- `manifest_version: 3` : l’extension utilise Manifest V3, le format actuel recommandé par Chrome.
- `permissions` et `host_permissions` : définissent ce à quoi l’extension a accès (onglets, URLs Gmail/Outlook, etc.).
- `background.service_worker` : déclare `background.js` comme **service worker** de fond.
- `content_scripts` : injecte `content.js` sur les pages cibles (Gmail, Outlook, autres URLs).
- `action.default_popup` : définit l’interface popup (`popup.html`).
- `web_accessible_resources` : permet d’exposer certaines ressources (comme l’icône) au contenu des pages.

Pourquoi ce choix ?

- Manifest V3 est le standard moderne pour les extensions Chrome (meilleure sécurité, limitations plus claires).
- L’utilisation de `content_scripts` + `background.service_worker` est le schéma classique et le plus lisible pour ce type d’extension.

---

### 2. `background.js` – Service worker de fond

Ce fichier gère :

- les statistiques globales liées à l’analyse des URLs (`novaxStats`) ;
- la communication avec les autres parties via `chrome.runtime.onMessage` ;
- les appels HTTP vers l’API locale d’analyse (`server.js`).

Logique principale :

- À chaque fois qu’un composant envoie un message avec `action: "analyzeUrl"`, le background :
  - appelle l’API `http://localhost:3000/analyze` en POST avec l’URL ;
  - met à jour les statistiques (`analyzed`, `safe`, `danger`) en fonction du résultat ;
  - renvoie au script appelant un objet `{ status, message, details }`.
- Quand le popup envoie `action: "getStats"`, le background renvoie simplement `novaxStats`.

**Pourquoi ce choix ?**

- Centraliser la logique d’appel à l’API dans `background.js` :
  - évite de dupliquer la logique dans le content script et le popup ;
  - permet de maintenir les **statistiques globales** dans un seul endroit.
- Utiliser `chrome.runtime.sendMessage` est la manière standard et simple de faire communiquer les différentes parties de l’extension.

---

### 3. `content.js` – Script de contenu

Ce script est injecté dans les pages (Gmail, Outlook, etc.) et :

- repère les liens (`<a>`) présents dans le DOM ;
- ajoute des listeners de survol (mouseenter / mouseleave / mousemove) sur ces liens ;
- affiche un tooltip NovaX (dans un Shadow DOM) lorsque l’utilisateur survole un lien ;
- demande au background d’**analyser l’URL** et met à jour le tooltip avec le résultat.

Points importants :

- Utilisation d’un Shadow DOM :
  - le tooltip est isolé du CSS de la page ;
  - on évite les conflits de styles et les effets de bord.
- Utilisation d’un debounce lors du survol des liens :
  - on ne lance pas une requête d’analyse à chaque micro mouvement de la souris ;
  - l’analyse ne se déclenche qu’après un petit délai (`CONFIG.DEBOUNCE_MS`).
- Extraction de la “vraie” URL :
  - certains webmails masquent l’URL réelle derrière une redirection (Google, Outlook) ;
  - `getRealUrl` tente de retrouver l’URL finale via les paramètres (`q`, `url`, `u`) ou les attributs `data-*`.

**Pourquoi ce choix ?**

- Le **content script** est le seul endroit autorisé à interagir directement avec le DOM de la page.
- Le **Shadow DOM** garantit que l’UI de NovaX reste propre et stable quel que soit le site.
- Le **debounce** limite le nombre d’appels réseau et améliore la fluidité.
- L’extraction d’URL réelle est indispensable pour détecter du phishing dans des liens de type “redirigé”.

---

### 4. `popup.html` / `popup.js` – Interface popup

Le popup est la petite fenêtre qui s’ouvre quand on clique sur l’icône de l’extension dans la barre du navigateur.

- `popup.html` définit la structure et le style :
  - en-tête avec logo NovaX ;
  - carte de statistiques : “Sites analysés”, “Menaces bloquées” ;
  - bouton pour ouvrir un “tableau de bord” ;
  - pied de page avec un texte de version.

- `popup.js` gère la logique :
  - au chargement (`DOMContentLoaded`), envoie un message au background (`"getStats"`) ;
  - met à jour les valeurs affichées dans le popup avec les statistiques reçues ;
  - récupère l’onglet actif pour afficher “Protection active sur <domaine>” ;
  - ouvre un nouvel onglet sur `https://novax.local/dashboard` quand on clique sur le bouton.

**Pourquoi ce choix ?**

- Le popup sert d’interface utilisateur centralisée :
  - permet de voir l’état global de la protection ;
  - reste simple et non intrusif.
- Le lien avec le background via `getStats` évite d’avoir plusieurs sources de vérité : toutes les stats restent dans `background.js`.

---

### 5. `server.js` / `package.json` – API locale de test

`server.js` est un petit serveur HTTP Node.js qui simule un backend d’analyse :

- exposé sur `http://localhost:3000/analyze` ;
- accepte des requêtes POST avec un JSON `{ "url": "..." }` ;
- applique quelques **règles simples** :
  - si l’URL contient `paypal` mais pas `paypal.com` → statut `danger` ;
  - si l’URL contient `danger` ou `phishing` → statut `danger` ;
  - sinon → statut `safe`.
- renvoie un objet `{ status, message, details }` cohérent avec ce qu’attend l’extension.

`package.json` sert uniquement à :

- décrire le projet Node ;
- exposer un script `npm start` pour lancer le serveur.

**Pourquoi ce choix ?**

- Avoir un mock API local permet :
  - de développer et tester l’extension sans dépendre d’un vrai backend en ligne ;
  - de simuler des cas de phishing de manière contrôlée.
- L’utilisation du module `http` natif de Node évite d’introduire des dépendances (Express, etc.) pour quelque chose de très simple.

---

## Flux de données global

Voici le flux typique pour l’analyse d’un lien :

1. L’utilisateur survole un lien dans sa messagerie.
2. `content.js` détecte le survol et récupère l’URL réelle.
3. `content.js` affiche un tooltip “Analyse NovaX…” et envoie un message au background :
   - `{ action: "analyzeUrl", url: "<lien>" }`.
4. `background.js` reçoit le message, appelle `http://localhost:3000/analyze` avec l’URL.
5. `server.js` renvoie un statut (`safe` / `danger` / `error`) avec un message.
6. `background.js` met à jour `novaxStats` et renvoie la réponse au content script.
7. `content.js` met à jour le tooltip (icone, couleurs, message).

Pour le popup :

1. L’utilisateur ouvre le popup.
2. `popup.js` envoie `{ action: "getStats" }` au background.
3. `background.js` renvoie `novaxStats`.
4. Le popup met à jour les valeurs affichées.

---

## Comment lancer le projet en local

1. **Installer Node.js** si ce n’est pas déjà fait.
2. Dans ce dossier, lancer le serveur mock :

```bash
npm install   # s’il n’a jamais été lancé, ou pour être cohérent avec l’écosystème
npm start     # lance server.js sur http://localhost:3000
```

3. **Charger l’extension dans Chrome** :
   - Ouvrir `chrome://extensions/`.
   - Activer “Mode développeur”.
   - Cliquer sur “Charger l’extension non empaquetée”.
   - Sélectionner le dossier `NovaX-Extension`.

4. Aller sur Gmail / Outlook, survoler des liens et observer le tooltip NovaX.

---

## Évolutions possibles

Quelques pistes d’évolution cohérentes avec l’architecture actuelle :

- Remplacer le mock API local (`server.js`) par un **vrai backend sécurisé**.
- Enrichir les règles d’analyse (score de confiance, catégories de risques).
- Persister les statistiques au-delà de la session (storage Chrome ou backend).
- Ajouter une page d’options pour configurer certains comportements (sensibilité, liste blanche de domaines, etc.).

L’architecture actuelle (content script + background + popup + mock API) est déjà prête pour accueillir ces évolutions de façon progressive.

