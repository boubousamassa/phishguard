const NOVAX_CONFIG = {
  API: {
    BASE_URL: "http://localhost:3000",
    ENDPOINTS: {
      analyze: "/analyze",
    },
    TIMEOUT_MS: 2000,
  },

  CACHE: {
    TTL_MS: 5 * 60 * 1000,
    MAX_ENTRIES: 500,
  },

  UI: {
    DEBOUNCE_MS: 300,
    TOOLTIP_OFFSET: 20,
    TOOLTIP_MAX_WIDTH: 300,
    TOOLTIP_ESTIMATED_HEIGHT: 150,
    COLORS: {
      PRIMARY: "#6366f1",
      SAFE: "#22c55e",
      DANGER: "#ef4444",
      WARNING: "#f59e0b",
      TEXT: "#1e293b",
    },
  },
};
