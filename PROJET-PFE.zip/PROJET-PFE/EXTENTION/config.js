const NOVAX_CONFIG = {
  API: {
    BASE_URL: "http://192.168.200.2:5000",
    ENDPOINTS: {
      analyze: "/analyse_url"
    },
    TIMEOUT_MS: 10000
  },
  CACHE: {
    TTL_MS: 5 * 60 * 1000,
    MAX_ENTRIES: 200
  }
};