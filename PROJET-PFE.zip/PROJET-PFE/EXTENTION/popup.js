// ── État On/Off ──────────────────────────────────────────────────────────────
const toggle      = document.getElementById('novax-toggle');
const toggleLabel = document.getElementById('novax-toggle-label');
const statusLabel = document.getElementById('novax-status-label');

chrome.storage.local.get('novaxEnabled', (data) => {
  const enabled = data.novaxEnabled !== false;
  toggle.checked = enabled;
  updateUI(enabled);
});

toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  chrome.storage.local.set({ novaxEnabled: enabled });
  chrome.runtime.sendMessage({ action: 'toggleProtection', enabled });
  updateUI(enabled);
  document.body.classList.toggle('disabled', !enabled);
});

function updateUI(enabled) {
  toggleLabel.textContent = enabled ? 'Activé' : 'Désactivé';
  statusLabel.textContent = enabled ? 'Protection active' : 'Protection désactivée';
  document.body.classList.toggle('disabled', !enabled);
}

// ── Stats ────────────────────────────────────────────────────────────────────
chrome.runtime.sendMessage({ action: 'getStats' }, (response) => {
  if (response && response.stats) {
    document.getElementById('novax-count-analyzed').textContent = response.stats.analyzed || 0;
    document.getElementById('novax-count-danger').textContent   = response.stats.danger   || 0;
  }
});

// ── Ouvrir le dashboard ───────────────────────────────────────────────────────
document.getElementById('novax-open-dashboard').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'openDashboard' });
  window.close();
});