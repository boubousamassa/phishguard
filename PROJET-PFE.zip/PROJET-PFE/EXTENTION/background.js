importScripts("config.js");

// ── Cache mémoire ────────────────────────────────────────────────────────────
const urlCache = new Map();

function getCachedResult(url) {
  const entry = urlCache.get(url);
  if (!entry) return null;
  if (Date.now() - entry.timestamp > NOVAX_CONFIG.CACHE.TTL_MS) { urlCache.delete(url); return null; }
  return entry.result;
}

function setCachedResult(url, result) {
  if (urlCache.size >= NOVAX_CONFIG.CACHE.MAX_ENTRIES) urlCache.delete(urlCache.keys().next().value);
  urlCache.set(url, { result, timestamp: Date.now() });
}

// ── Adaptateur Flask → format interne ───────────────────────────────────────
function adaptFlaskResponse(data) {
  const verdict = (data.verdict || "").toUpperCase();
  if (verdict === "DANGER") return { status: "danger", message: "Phishing détecté",  details: "Cette URL est blacklistée dans la base NovaX." };
  if (verdict === "SAFE")   return { status: "safe",   message: "Lien vérifié",      details: "Aucune menace détectée." };
  return { status: "warning", message: "Résultat inconnu", details: "L'API n'a pas retourné de verdict clair." };
}

// ── Storage ──────────────────────────────────────────────────────────────────
let novaxStats   = { analyzed: 0, safe: 0, danger: 0 };
let novaxHistory = [];
const MAX_HISTORY = 500;

async function loadStorage() {
  try {
    const data = await chrome.storage.local.get(["novaxStats", "novaxHistory"]);
    if (data.novaxStats)   novaxStats   = data.novaxStats;
    if (data.novaxHistory) novaxHistory = data.novaxHistory;
  } catch (e) { console.warn("NovaX: chargement échoué", e); }
}

async function saveStorage() {
  try { await chrome.storage.local.set({ novaxStats, novaxHistory }); }
  catch (e) { console.warn("NovaX: sauvegarde échouée", e); }
}

function addToHistory(url, result) {
  const last = novaxHistory[novaxHistory.length - 1];
  if (last && last.url === url) return;
  novaxHistory.push({ url, status: result.status, message: result.message, ts: Date.now() });
  if (novaxHistory.length > MAX_HISTORY) novaxHistory = novaxHistory.slice(-MAX_HISTORY);
}

// ── Notifier le dashboard s'il est ouvert ───────────────────────────────────
async function notifyDashboard() {
  try {
    const dashboardUrl = chrome.runtime.getURL("dashboard.html");
    const tabs = await chrome.tabs.query({ url: dashboardUrl });
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, {
        action: "dataUpdated",
        history: novaxHistory,
        stats:   novaxStats,
      }).catch(() => {}); // ignore si l'onglet n'a pas encore de listener
    }
  } catch (e) {}
}

loadStorage();

// ── Messages ─────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request.action === "analyzeUrl") {
    handleUrlAnalysis(request.url, sendResponse);
    return true;
  }
  if (request.action === "getStats") {
    sendResponse({ stats: novaxStats });
  }
  if (request.action === "getDashboardData") {
    sendResponse({ history: novaxHistory, stats: novaxStats });
  }
  if (request.action === "clearHistory") {
    novaxStats   = { analyzed: 0, safe: 0, danger: 0 };
    novaxHistory = [];
    saveStorage();
    sendResponse({ ok: true });
  }
  if (request.action === "openDashboard") {
    chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
  }
});

// ── Analyse ───────────────────────────────────────────────────────────────────
async function handleUrlAnalysis(url, sendResponse) {
  const data = await chrome.storage.local.get("novaxEnabled");
  if (data.novaxEnabled === false) { sendResponse({ status: "disabled", message: "Extension désactivée" }); return; }

  const cached = getCachedResult(url);
  if (cached) { sendResponse(cached); return; }

  const apiUrl     = NOVAX_CONFIG.API.BASE_URL + NOVAX_CONFIG.API.ENDPOINTS.analyze;
  const controller = new AbortController();
  const timeoutId  = setTimeout(() => controller.abort(), NOVAX_CONFIG.API.TIMEOUT_MS);

  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (!response.ok) throw new Error(`API error: ${response.status}`);

    const adapted = adaptFlaskResponse(await response.json());

    novaxStats.analyzed += 1;
    if (adapted.status === "safe")   novaxStats.safe   += 1;
    if (adapted.status === "danger") novaxStats.danger += 1;

    addToHistory(url, adapted);
    setCachedResult(url, adapted);
    await saveStorage();

    // Notifier le dashboard en temps réel
    notifyDashboard();

    sendResponse(adapted);
  } catch (error) {
    clearTimeout(timeoutId);
    const isTimeout = error.name === "AbortError";
    sendResponse({
      status:  "error",
      message: isTimeout ? "Timeout" : "Erreur d'analyse",
      details: isTimeout ? "Le serveur n'a pas répondu à temps." : "Impossible de contacter le serveur.",
    });
  }
}