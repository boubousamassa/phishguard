// Petit serveur HTTP local jouant le rôle de mock pour l’API NovaX
const http = require('http');

// Port d’écoute du serveur de test
const PORT = 3000;

// Route principale de l’API factice
const server = http.createServer((req, res) => {
   
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // Gestion basique du pré‑vol CORS
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    // Endpoint utilisé par l’extension pour analyser une URL
    if (req.method === 'POST' && req.url === '/analyze') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });

        req.on('end', () => {
            try {
                // Récupère l’URL envoyée par l’extension
                const { url } = JSON.parse(body);
                console.log(`Analyzing URL: ${url}`);

                
                // Simulation de latence pour imiter un appel réseau réel
                setTimeout(() => {
                    let result;
                   
                    // Quelques règles simples pour marquer des URLs “dangereuses”
                    if (url.includes('paypal') && !url.includes('paypal.com')) {
                         result = {
                            status: 'danger',
                            message: 'PHISHING DÉTECTÉ',
                            details: 'Ce lien tente d\'imiter PayPal.'
                        };
                    } else if (url.includes('danger') || url.includes('phishing')) {
                        result = {
                            status: 'danger',
                            message: 'PHISHING DÉTECTÉ',
                            details: 'Site signalé dans la base NovaX.'
                        };
                    } else {
                        result = {
                            status: 'safe',
                            message: 'Lien Vérifié',
                            details: 'Aucune menace détectée.'
                        };
                    }

                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify(result));
                }, 1500); 

            } catch (error) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Invalid JSON' }));
            }
        });
    } else {
        res.writeHead(404);
        res.end();
    }
});

server.listen(PORT, () => {
    console.log(`NovaX Mock API Server running on http://localhost:${PORT}`);
});
