// NovaX Content Script
// Tooltip de sécurité au survol + blocage de navigation sur liens dangereux

let tooltipHost = null;
let tooltipRoot = null;
let tooltipContainer = null;
let currentTarget = null;
let debounceTimer = null;
let protectionEnabled = true;

// Cache local des résultats connus (partagé avec le blocage au clic)
const linkResultCache = new Map();
console.log("NovaX content chargé");

// ── Synchronisation de l'état On/Off ────────────────────────────────────────
chrome.storage.local.get("novaxEnabled", (data) => {
  protectionEnabled = data.novaxEnabled !== false;
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "toggleProtection") {
    protectionEnabled = msg.enabled;
    if (!protectionEnabled) {
      hideTooltip();
    }
  }
});

// ── Configuration (dupliquée car le content script n'a pas accès à importScripts) ──
const CONFIG = {
  DEBOUNCE_MS: 300,
  TOOLTIP_OFFSET: 20,
  TOOLTIP_MAX_WIDTH: 300,
  TOOLTIP_ESTIMATED_HEIGHT: 150,
  COLORS: {
    PRIMARY: "#6366f1",
    SAFE: "#22c55e",
    DANGER: "#ef4444",
    WARNING: "#f59e0b",
    TEXT: "#1e293b",
  },
};

// ── Initialisation ──────────────────────────────────────────────────────────
function init() {
  createTooltipInfrastructure();
  startObserving();
}

// ── Shadow DOM pour le tooltip ──────────────────────────────────────────────
function createTooltipInfrastructure() {
  if (document.getElementById("novax-tooltip-host")) return;

  tooltipHost = document.createElement("div");
  tooltipHost.id = "novax-tooltip-host";
  tooltipHost.style.cssText =
    "position:fixed;top:0;left:0;z-index:2147483647;pointer-events:none;";

  document.body.appendChild(tooltipHost);
  tooltipRoot = tooltipHost.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `
    .novax-tooltip {
      position: fixed;
      background: white;
      border-radius: 8px;
      box-shadow: 0 10px 15px -3px rgba(0,0,0,.1), 0 4px 6px -2px rgba(0,0,0,.05);
      font-family: 'Segoe UI', system-ui, sans-serif;
      font-size: 14px;
      padding: 12px;
      min-width: 200px;
      max-width: ${CONFIG.TOOLTIP_MAX_WIDTH}px;
      opacity: 0;
      transform: translateY(10px);
      transition: opacity .2s, transform .2s;
      pointer-events: auto;
      border: 1px solid #e2e8f0;
      display: none;
    }
    .novax-tooltip.visible { opacity:1; transform:translateY(0); display:block; }

    .novax-header {
      display: flex; align-items: center;
      margin-bottom: 8px; font-weight: 600;
      font-size: 13px; text-transform: uppercase; letter-spacing: .05em;
    }
    .novax-logo {
      width:16px; height:16px; margin-right:8px;
      background-color: ${CONFIG.COLORS.PRIMARY};
      border-radius:4px; display:flex; align-items:center; justify-content:center;
      color:white; font-weight:bold; font-size:10px;
    }
    .novax-status-text { flex:1; }
    .novax-url {
      color:#64748b; font-size:12px;
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
      margin-bottom:8px; border-bottom:1px solid #f1f5f9; padding-bottom:8px;
    }
    .novax-message { color:${CONFIG.COLORS.TEXT}; font-size:13px; line-height:1.4; }

    .state-loading .novax-header { color:${CONFIG.COLORS.PRIMARY}; }
    .state-safe    .novax-header { color:${CONFIG.COLORS.SAFE}; }
    .state-danger  .novax-header { color:${CONFIG.COLORS.DANGER}; }
    .state-warning .novax-header { color:${CONFIG.COLORS.WARNING}; }

    .state-danger  .novax-tooltip { border-left:4px solid ${CONFIG.COLORS.DANGER}; }
    .state-safe    .novax-tooltip { border-left:4px solid ${CONFIG.COLORS.SAFE}; }
    .state-warning .novax-tooltip { border-left:4px solid ${CONFIG.COLORS.WARNING}; }

    .spinner {
      width:12px; height:12px;
      border:2px solid #e2e8f0; border-top:2px solid ${CONFIG.COLORS.PRIMARY};
      border-radius:50%; animation:spin 1s linear infinite; margin-right:8px;
    }
    @keyframes spin { 0%{transform:rotate(0deg)} 100%{transform:rotate(360deg)} }

    /* Overlay de blocage */
    .novax-block-overlay {
      position:fixed; inset:0;
      background:rgba(0,0,0,.6); z-index:2147483647;
      display:flex; align-items:center; justify-content:center;
      pointer-events:auto;
    }
    .novax-block-card {
      background:white; border-radius:12px; padding:32px; max-width:420px;
      text-align:center; box-shadow:0 25px 50px -12px rgba(0,0,0,.25);
      font-family:'Segoe UI',system-ui,sans-serif;
    }
    .novax-block-card h2 {
      color:${CONFIG.COLORS.DANGER}; margin:0 0 12px; font-size:20px;
    }
    .novax-block-card p {
      color:#475569; font-size:14px; line-height:1.5; margin:0 0 8px;
    }
    .novax-block-card .url-display {
      color:#94a3b8; font-size:12px; word-break:break-all;
      background:#f8fafc; padding:8px; border-radius:6px; margin:12px 0;
    }
    .novax-block-btns { display:flex; gap:10px; margin-top:20px; justify-content:center; }
    .novax-block-btns button {
      padding:10px 20px; border-radius:6px; font-size:14px;
      font-weight:500; cursor:pointer; border:none; transition:background .2s;
    }
    .novax-btn-back {
      background:${CONFIG.COLORS.PRIMARY}; color:white;
    }
    .novax-btn-back:hover { background:#4f46e5; }
    .novax-btn-proceed {
      background:transparent; color:#94a3b8; border:1px solid #e2e8f0 !important;
    }
    .novax-btn-proceed:hover { background:#f8fafc; }
  `;
  tooltipRoot.appendChild(style);

  tooltipContainer = document.createElement("div");
  tooltipContainer.className = "novax-tooltip";
  tooltipContainer.innerHTML = `
    <div class="novax-content">
      <div class="novax-header">
        <div class="novax-logo">N</div>
        <span class="novax-status-text">Analyse...</span>
      </div>
      <div class="novax-url"></div>
      <div class="novax-message"></div>
    </div>
  `;
  tooltipRoot.appendChild(tooltipContainer);
}

// ── Observation du DOM ──────────────────────────────────────────────────────
function startObserving() {
  attachListenersToLinks(document.body);

  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type === "childList") {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            attachListenersToLinks(node);
          }
        });
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

function attachListenersToLinks(rootNode) {
  const links = rootNode.querySelectorAll
    ? rootNode.querySelectorAll("a")
    : [];
  links.forEach((link) => attachToLink(link));

  if (rootNode.tagName === "A") {
    attachToLink(rootNode);
  }
}

function attachToLink(link) {
  if (link.dataset.novaxObserved) return;
  link.dataset.novaxObserved = "true";

  link.addEventListener("mouseenter", handleLinkMouseEnter);
  link.addEventListener("mouseleave", handleLinkMouseLeave);
  link.addEventListener("mousemove", handleLinkMouseMove, { passive: true });
  link.addEventListener("click", handleLinkClick, true);
}

// ── Gestionnaires d'événements ──────────────────────────────────────────────
function handleLinkMouseEnter(e) {
  if (!protectionEnabled) return;
  const link = e.currentTarget;
  currentTarget = link;

  if (debounceTimer) clearTimeout(debounceTimer);

  debounceTimer = setTimeout(() => {
    if (currentTarget !== link) return;
    const url = getRealUrl(link);
    showTooltipLoading(e.clientX, e.clientY, url || "Lien non analysable");

    if (url && isValidUrl(url)) {
      analyzeUrl(url);
    } else {
      updateTooltipError();
    }
  }, CONFIG.DEBOUNCE_MS);
}

function handleLinkMouseLeave() {
  currentTarget = null;
  if (debounceTimer) clearTimeout(debounceTimer);
  setTimeout(() => hideTooltip(), 100);
}

function handleLinkMouseMove(e) {
  if (!currentTarget) return;
  positionTooltip(e.clientX, e.clientY);
}

// Bloque la navigation si le lien a déjà été identifié comme dangereux
function handleLinkClick(e) {
  if (!protectionEnabled) return;
  const link = e.currentTarget;
  const url = getRealUrl(link);
  if (!url) return;

  const cached = linkResultCache.get(url);
  if (cached && cached.status === "danger") {
    e.preventDefault();
    e.stopImmediatePropagation();
    showBlockingOverlay(url);
  }
}

// ── Overlay de blocage ──────────────────────────────────────────────────────
function showBlockingOverlay(url) {
  if (!tooltipRoot) return;

  const existing = tooltipRoot.querySelector(".novax-block-overlay");
  if (existing) existing.remove();

  const overlay = document.createElement("div");
  overlay.className = "novax-block-overlay";
  overlay.innerHTML = `
    <div class="novax-block-card">
      <h2>⚠ Lien dangereux bloqué</h2>
      <p>NovaX a détecté que ce lien est une menace de phishing connue.</p>
      <div class="url-display">${escapeHtml(url)}</div>
      <p>Nous vous recommandons fortement de ne pas continuer.</p>
      <div class="novax-block-btns">
        <button class="novax-btn-back" data-action="close">Revenir en sécurité</button>
        <button class="novax-btn-proceed" data-action="proceed">Continuer quand même</button>
      </div>
    </div>
  `;

  overlay.addEventListener("click", (e) => {
    const action = e.target.dataset.action;
    if (action === "close") {
      overlay.remove();
    } else if (action === "proceed") {
      overlay.remove();
      window.open(url, "_blank", "noopener,noreferrer");
    }
  });

  tooltipRoot.appendChild(overlay);
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ── Extraction d'URL ────────────────────────────────────────────────────────
function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}

function getRealUrl(link) {
  const raw = link.getAttribute("href") || "";
  try {
    const u = new URL(raw);
    if (
      u.hostname === "www.google.com" &&
      u.pathname === "/url" &&
      u.searchParams.has("q")
    ) {
      return u.searchParams.get("q");
    }
    if (u.searchParams.has("url")) return u.searchParams.get("url");
    if (u.searchParams.has("u")) return u.searchParams.get("u");
  } catch (_) {}

  if (link.dataset && (link.dataset.href || link.dataset.url)) {
    return link.dataset.href || link.dataset.url;
  }
  return raw;
}

// ── Communication avec le background ────────────────────────────────────────
function analyzeUrl(url) {
  chrome.runtime.sendMessage({ action: "analyzeUrl", url }, (response) => {
    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError);
      updateTooltipError();
      return;
    }

    if (response) {
      linkResultCache.set(url, response);
      updateTooltipResult(response);
    }
  });
}

// ── Tooltip : affichage ─────────────────────────────────────────────────────
function showTooltipLoading(x, y, url) {
  if (!tooltipContainer) return;

  tooltipContainer.className = "novax-tooltip visible state-loading";

  const header = tooltipRoot.querySelector(".novax-header");
  header.innerHTML =
    '<div class="spinner"></div><span class="novax-status-text">Analyse NovaX\u2026</span>';

  tooltipRoot.querySelector(".novax-url").textContent = url;
  tooltipRoot.querySelector(".novax-message").textContent =
    "Vérification de la sécurité du lien\u2026";

  positionTooltip(x, y);
}

function updateTooltipResult(data) {
  if (!tooltipContainer) return;

  const { status, message, details } = data;

  let state = "warning";
  let icon = "?";
  if (status === "safe") {
    state = "safe";
    icon = "✓";
  } else if (status === "danger") {
    state = "danger";
    icon = "⚠";
  }

  tooltipContainer.className = `novax-tooltip visible state-${state}`;

  const header = tooltipRoot.querySelector(".novax-header");
  header.innerHTML = `<div class="novax-logo">${icon}</div><span class="novax-status-text">${escapeHtml(message || "Résultat inconnu")}</span>`;

  tooltipRoot.querySelector(".novax-message").textContent =
    details || "Aucun détail disponible.";
}

function updateTooltipError() {
  if (!tooltipContainer) return;

  tooltipContainer.className = "novax-tooltip visible state-danger";

  const header = tooltipRoot.querySelector(".novax-header");
  header.innerHTML =
    '<div class="novax-logo">!</div><span class="novax-status-text">Erreur</span>';

  tooltipRoot.querySelector(".novax-message").textContent =
    "Impossible d'analyser ce lien pour le moment.";
}

function hideTooltip() {
  if (tooltipContainer) {
    tooltipContainer.classList.remove("visible");
  }
}

// Position relative au viewport (le host est en position:fixed)
function positionTooltip(x, y) {
  if (!tooltipContainer) return;

  const offset = CONFIG.TOOLTIP_OFFSET;
  let top = y + offset;
  let left = x + offset;

  if (left + CONFIG.TOOLTIP_MAX_WIDTH > window.innerWidth) {
    left = x - CONFIG.TOOLTIP_MAX_WIDTH;
  }
  if (top + CONFIG.TOOLTIP_ESTIMATED_HEIGHT > window.innerHeight) {
    top = y - CONFIG.TOOLTIP_ESTIMATED_HEIGHT - offset;
  }
  if (top < 0) top = offset;
  if (left < 0) left = offset;

  tooltipContainer.style.top = `${top}px`;
  tooltipContainer.style.left = `${left}px`;
}

// ── Démarrage ───────────────────────────────────────────────────────────────
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
