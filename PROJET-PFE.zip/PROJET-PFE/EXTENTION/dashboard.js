const API = "http://192.168.200.2:5000";

let allEntries    = [];
let currentFilter = 'all';
let prevTotal     = -1;

// ── Fetch ─────────────────────────────────────────────────────────────────────
async function fetchStats() {
  const res = await fetch(`${API}/stats`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function fetchHistory() {
  const res = await fetch(`${API}/history?limit=200`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

// ── Refresh principal ─────────────────────────────────────────────────────────
async function refresh() {
  try {
    const [stats, history] = await Promise.all([fetchStats(), fetchHistory()]);

    document.getElementById('live-dot').classList.remove('error');
    document.getElementById('live-label').textContent = 'Temps réel';
    document.getElementById('error-banner').classList.remove('visible');

    const flash = prevTotal !== -1 && stats.total !== prevTotal;
    prevTotal = stats.total;
    setKpi('kpi-total',  stats.total,  flash);
    setKpi('kpi-safe',   stats.safe,   flash);
    setKpi('kpi-danger', stats.danger, flash);

    const hadNew = history.length > allEntries.length;
    allEntries = history;
    renderTable(hadNew);

  } catch (err) {
    document.getElementById('live-dot').classList.add('error');
    document.getElementById('live-label').textContent = 'Hors ligne';
    const banner = document.getElementById('error-banner');
    banner.textContent = `Impossible de contacter l'API Flask : ${err.message} — vérifiez que l'API tourne sur ${API}`;
    banner.classList.add('visible');
  }
}

// ── KPI ───────────────────────────────────────────────────────────────────────
function setKpi(id, value, flash) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = value;
  if (flash) {
    el.classList.remove('flash');
    void el.offsetWidth;
    el.classList.add('flash');
  }
}

// ── Tableau ───────────────────────────────────────────────────────────────────
function renderTable(animateFirst) {
  const tbody  = document.getElementById('table-body');
  const empty  = document.getElementById('empty-state');
  const search = document.getElementById('search-input').value.toLowerCase();

  let filtered = allEntries.filter(e => {
    const matchFilter = currentFilter === 'all' || e.verdict === currentFilter;
    const matchSearch = !search || e.url.toLowerCase().includes(search);
    return matchFilter && matchSearch;
  });

  tbody.innerHTML = '';

  if (filtered.length === 0) {
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';

  filtered.forEach((entry, i) => {
    const tr = document.createElement('tr');
    if (animateFirst && i === 0) tr.classList.add('row-new');

    const badge = entry.verdict === 'SAFE'
      ? `<span class="badge badge-safe"><span class="badge-dot"></span>Sûr</span>`
      : `<span class="badge badge-danger"><span class="badge-dot"></span>Danger</span>`;

    const time = entry.ts
      ? new Date(entry.ts).toLocaleString('fr-FR', {
          day:'2-digit', month:'2-digit', year:'numeric',
          hour:'2-digit', minute:'2-digit'
        })
      : '—';

    tr.innerHTML = `
      <td class="td-num">${filtered.length - i}</td>
      <td class="td-url"><a href="${esc(entry.url)}" target="_blank" rel="noopener noreferrer">${esc(entry.url)}</a></td>
      <td>${badge}</td>
      <td class="td-ip">${esc(entry.origine || '—')}</td>
      <td class="td-time">${time}</td>
    `;
    tbody.appendChild(tr);
  });
}

function esc(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── Filtres ───────────────────────────────────────────────────────────────────
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderTable(false);
  });
});

document.getElementById('search-input').addEventListener('input', () => renderTable(false));

// ── Init + polling toutes les 5s ──────────────────────────────────────────────
refresh();
setInterval(refresh, 5000);