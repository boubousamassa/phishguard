import { getSupabaseClient} from '../config/supabase.js';

/**
 * Service de gestion utilisateur - 4students-NovaX
 * Gère les niveaux, XP, achievements, vidéos, tips et progression globale
 */
export const userService = {
  /** Récupère le niveau et les XP d'un utilisateur */
  async getUserLevel(userId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_levels')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return { success: true, data: data || null };
    } catch (error) {
      console.error('Erreur lors de la récupération du niveau:', error);
      return { success: false, error: error.message };
    }
  },

  /** Crée ou met à jour le niveau d'un utilisateur (upsert) */
  async upsertUserLevel(userId, levelData) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_levels')
        .upsert({
          user_id: userId,
          level: levelData.level || 1,
          xp: levelData.xp || 0,
          total_points: levelData.total_points || 0,
          last_update: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la mise à jour du niveau:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère les vidéos visionnées par l'utilisateur avec leur progression */
  async getUserVideos(userId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_video_progress')
        .select(`
          *,
          videos (*)
        `)
        .eq('user_id', userId);

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des vidéos:', error);
      return { success: false, error: error.message };
    }
  },

  /** Met à jour la progression de visionnage d'une vidéo */
  async updateVideoProgress(userId, videoId, watchedSec, completed) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_video_progress')
        .upsert({
          user_id: userId,
          video_id: videoId,
          watched_sec: watchedSec,
          completed: completed,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id,video_id'
        });

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la mise à jour du progrès:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère l'historique des sessions de quiz de l'utilisateur */
  async getUserQuizSessions(userId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_quiz_sessions')
        .select(`
          *,
          quizzes (*)
        `)
        .eq('user_id', userId)
        .order('completed_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des quiz:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère les achievements débloqués par l'utilisateur */
  async getUserAchievements(userId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_achievements')
        .select(`
          *,
          achievements (*)
        `)
        .eq('user_id', userId)
        .order('unlocked_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des achievements:', error);
      return { success: false, error: error.message };
    }
  },

  /** 
   * Liste tous les achievements avec leur statut pour un utilisateur
   * Permet d'afficher ce qui est débloqué et ce qui reste à débloquer
   */
  async getAllAchievementsWithStatus(userId) {
    try {
      const supabase = await getSupabaseClient();
      
      // Charger tous les achievements disponibles
      const { data: allAchievements, error: allError } = await supabase
        .from('achievements')
        .select('*')
        .order('level_required', { ascending: true });
      
      if (allError) throw allError;
      
      // Charger les achievements déjà débloqués
      const { data: userAchievements, error: userError } = await supabase
        .from('user_achievements')
        .select('achievement_id, unlocked_at')
        .eq('user_id', userId);
      
      if (userError) throw userError;
      
      // Combiner les deux pour indiquer le statut
      const achievementsWithStatus = allAchievements.map(achievement => ({
        ...achievement,
        unlocked: userAchievements.some(ua => ua.achievement_id === achievement.id),
        unlocked_at: userAchievements.find(ua => ua.achievement_id === achievement.id)?.unlocked_at || null
      }));
      
      return { success: true, data: achievementsWithStatus };
    } catch (error) {
      console.error('Erreur lors de la récupération des achievements:', error);
      return { success: false, error: error.message };
    }
  },

  /** 
   * Débloque un achievement et attribue les XP correspondants
   * Vérifie qu'il n'est pas déjà débloqué avant
   */
  async unlockAchievement(userId, achievementCode) {
    try {
      const supabase = await getSupabaseClient();
      
      // Rechercher l'achievement par code
      const { data: achievement, error: findError } = await supabase
        .from('achievements')
        .select('id, name')
        .eq('code', achievementCode)
        .single();
      
      if (findError) throw findError;
      
      // Vérifier qu'il n'est pas déjà débloqué
      const { data: existing } = await supabase
        .from('user_achievements')
        .select('achievement_id')
        .eq('user_id', userId)
        .eq('achievement_id', achievement.id)
        .single();
      
      if (existing) {
        return { success: true, alreadyUnlocked: true };
      }
      
      // Débloquer l'achievement
      const { data, error } = await supabase
        .from('user_achievements')
        .insert({
          user_id: userId,
          achievement_id: achievement.id,
          unlocked_at: new Date().toISOString()
        })
        .select();
      
      if (error) throw error;
      
      // Attribution des récompenses XP selon le type d'achievement
      const xpRewards = {
        'first_quiz': 50,
        'email_expert': 100,
        'vigilant': 150,
        'cyber_defender': 300,
        'novax_master': 500,
        'perfect_100': 200
      };
      
      const xpToAdd = xpRewards[achievementCode] || 50;
      await this.addPoints(userId, xpToAdd, `Achievement débloqué: ${achievement.name}`);
      
      return { 
        success: true, 
        data, 
        alreadyUnlocked: false,
        achievementName: achievement.name,
        xpEarned: xpToAdd
      };
    } catch (error) {
      console.error('Erreur lors du déblocage de l\'achievement:', error);
      return { success: false, error: error.message };
    }
  },

  /** 
   * Ajoute des points XP et gère automatiquement la montée de niveau
   * Système : 100 XP = 1 niveau
   */
  async addPoints(userId, points, reason = '') {
    try {
      const supabase = await getSupabaseClient();
      
      // Charger le niveau actuel
      const levelResult = await this.getUserLevel(userId);
      let currentLevel = levelResult.data || { level: 1, xp: 0, total_points: 0 };
      
      // Calcul des nouveaux totaux
      const newXP = (currentLevel.xp || 0) + points;
      const newTotalPoints = (currentLevel.total_points || 0) + points;
      
      // Calcul du niveau (100 XP = 1 niveau)
      const XP_PER_LEVEL = 100;
      const newLevel = Math.floor(newXP / XP_PER_LEVEL) + 1;
      const xpInCurrentLevel = newXP % XP_PER_LEVEL;
      const leveledUp = newLevel > (currentLevel.level || 1);
      
      // Sauvegarde en base
      const { data, error } = await supabase
        .from('user_levels')
        .upsert({
          user_id: userId,
          level: newLevel,
          xp: newXP,
          total_points: newTotalPoints,
          last_update: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        })
        .select()
        .single();
      
      if (error) throw error;
      
      // Si niveau 5 atteint, débloquer automatiquement "Maître NovaX"
      if (leveledUp && newLevel >= 5) {
        const masterResult = await this.unlockAchievement(userId, 'novax_master');
        if (masterResult.success && !masterResult.alreadyUnlocked) {
          // Le badge Maître NovaX sera notifié à l'utilisateur
        }
      }
      
      return { 
        success: true, 
        data,
        pointsAdded: points,
        newLevel,
        leveledUp,
        xpInCurrentLevel,
        xpNeededForNextLevel: XP_PER_LEVEL - xpInCurrentLevel,
        reason
      };
    } catch (error) {
      console.error('Erreur lors de l\'ajout de points:', error);
      return { success: false, error: error.message };
    }
  },

  /** Calcule le nombre de points XP gagnés selon le score et la difficulté */
  calculateQuizPoints(score, difficulty) {
    const basePoints = {
      'beginner': 10,
      'intermediate': 15,
      'advanced': 20
    };
    
    const base = basePoints[difficulty] || 10;
    const scoreMultiplier = score / 10; // 0.0 à 1.0
    const bonusForPerfect = score === 10 ? 10 : 0;
    
    return Math.round(base * scoreMultiplier) + bonusForPerfect;
  },

  /** 
   * Enregistre la complétion d'un quiz, attribue les XP et vérifie les achievements
   * C'est la méthode principale appelée à la fin d'un quiz
   */
  async completeQuiz(userId, quizId, score, durationSec) {
    try {
      const supabase = await getSupabaseClient();
      
      // Charger les infos du quiz
      const { data: quiz, error: quizError } = await supabase
        .from('quizzes')
        .select('level, title')
        .eq('id', quizId)
        .single();
      
      if (quizError) throw quizError;
      
      // Sauvegarder la session
      const { data: session, error: sessionError } = await supabase
        .from('user_quiz_sessions')
        .insert({
          user_id: userId,
          quiz_id: quizId,
          score: score,
          completed_at: new Date().toISOString(),
          duration_sec: durationSec,
          attempt_index: 1
        })
        .select()
        .single();
      
      if (sessionError) throw sessionError;
      
      // Attribution des XP
      const points = this.calculateQuizPoints(score, quiz.level);
      await this.addPoints(userId, points, `Quiz complété: ${quiz.title} (${score}/10)`);
      
      // Vérification automatique des achievements
      const quizCount = await this.getUserQuizSessions(userId);
      const totalQuizzes = quizCount.data?.length || 0;
      
      // Achievement: Premier quiz
      if (totalQuizzes === 1) {
        await this.unlockAchievement(userId, 'first_quiz');
      }
      
      // Achievement: 5 quiz
      if (totalQuizzes === 5) {
        await this.unlockAchievement(userId, 'vigilant');
      }
      
      // Achievement: 10 quiz
      if (totalQuizzes === 10) {
        await this.unlockAchievement(userId, 'cyber_defender');
      }
      
      // Achievement: Score parfait
      if (score === 10) {
        await this.unlockAchievement(userId, 'perfect_100');
      }
      
      // Achievement: Expert email (score >= 9 sur quiz phishing)
      if (score >= 9 && quiz.title.toLowerCase().includes('email')) {
        await this.unlockAchievement(userId, 'email_expert');
      }
      
      return { 
        success: true, 
        session,
        pointsEarned: points
      };
    } catch (error) {
      console.error('Erreur lors de la complétion du quiz:', error);
      return { success: false, error: error.message };
    }
  },

  /** 
   * Vérifie les conditions d'achievements et retourne la progression
   * Utile pour afficher les achievements proches d'être débloqués
   */
  async checkAchievementConditions(userId) {
    try {
      const notifications = [];
      
      // Charger toutes les stats nécessaires
      const [levelResult, quizResult, achievementsResult] = await Promise.all([
        this.getUserLevel(userId),
        this.getUserQuizSessions(userId),
        this.getUserAchievements(userId)
      ]);
      
      const level = levelResult.data?.level || 1;
      const totalQuizzes = quizResult.data?.length || 0;
      const unlockedAchievements = achievementsResult.data?.map(a => a.achievements?.code) || [];
      
      // Liste des achievements à vérifier
      const achievements = [
        { code: 'first_quiz', condition: totalQuizzes >= 1, message: 'Complétez votre premier quiz' },
        { code: 'vigilant', condition: totalQuizzes >= 5, message: `${totalQuizzes}/5 quiz complétés` },
        { code: 'cyber_defender', condition: totalQuizzes >= 10, message: `${totalQuizzes}/10 quiz complétés` },
        { code: 'novax_master', condition: level >= 5, message: `Niveau ${level}/5` },
      ];
      
      for (const achievement of achievements) {
        if (!unlockedAchievements.includes(achievement.code)) {
          notifications.push({
            code: achievement.code,
            unlocked: achievement.condition,
            progress: achievement.message
          });
        }
      }
      
      return { success: true, notifications };
    } catch (error) {
      console.error('Erreur lors de la vérification des achievements:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère toutes les vidéos disponibles (catalogue complet) */
  async getAllVideos() {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des vidéos:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère tous les quiz actifs (catalogue complet) */
  async getAllQuizzes() {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('quizzes')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des quiz:', error);
      return { success: false, error: error.message };
    }
  },

  /** 
   * Récupère tous les tips disponibles
   * Mode dégradé: retourne [] si la table n'existe pas encore
   */
  async getAllTips() {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('tips')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) {
        // Gestion du cas où la table n'existe pas encore
        if (error.code === 'PGRST205' || error.code === '42703' || error.message?.includes('tips')) {
          console.warn('⚠️ Table tips non trouvée - fonctionnalité en attente de migration DB');
          return { success: true, data: [] };
        }
        throw error;
      }
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des tips:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère les tips sauvegardés/favoris d'un utilisateur */
  async getUserSavedTips(userId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_saved_tips')
        .select(`
          *,
          tips (*)
        `)
        .eq('user_id', userId);

      if (error) {
        // Mode dégradé si la table n'existe pas
        if (error.code === 'PGRST205' || error.message?.includes('user_saved_tips')) {
          console.warn('⚠️ Table user_saved_tips manquante - migration DB nécessaire');
          return { success: true, data: [] };
        }
        throw error;
      }
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des tips sauvegardés:', error);
      return { success: false, error: error.message };
    }
  },

  /** Ajoute un tip aux favoris de l'utilisateur */
  async saveTip(userId, tipId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_saved_tips')
        .insert({
          user_id: userId,
          tip_id: tipId,
          saved_at: new Date().toISOString()
        });

      if (error) {
        // Mode dégradé si table manquante
        if (error.code === 'PGRST205' || error.message?.includes('user_saved_tips')) {
          console.warn('⚠️ Sauvegarde impossible - table manquante');
          return { success: false, error: 'table_missing' };
        }
        throw error;
      }
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la sauvegarde du tip:', error);
      return { success: false, error: error.message };
    }
  },

  /** Retire un tip des favoris de l'utilisateur */
  async unsaveTip(userId, tipId) {
    try {
      const supabase = await getSupabaseClient();
      const { error } = await supabase
        .from('user_saved_tips')
        .delete()
        .eq('user_id', userId)
        .eq('tip_id', tipId);

      if (error) {
        // Mode dégradé si table manquante
        if (error.code === 'PGRST205' || error.message?.includes('user_saved_tips')) {
          console.warn('⚠️ Suppression impossible - table manquante');
          return { success: false, error: 'table_missing' };
        }
        throw error;
      }
      return { success: true };
    } catch (error) {
      console.error('Erreur lors de la suppression du tip:', error);
      return { success: false, error: error.message };
    }
  }
};

