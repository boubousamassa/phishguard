import { getSupabaseClient } from '../config/supabase.js';

/**
 * Service de gestion des quiz - 4students-NovaX
 * Centralise toutes les opérations liées aux quiz, questions, sessions et statistiques
 */
export const quizService = {
  // ========================================
  // QUIZ - Récupération et gestion
  // ========================================

  /** Récupère tous les quiz actifs avec leurs catégories */
  async getAllQuizzes() {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          *,
          quiz_categories (
            id,
            name,
            description
          )
        `)
        .eq('is_active', true)
        .order('level', { ascending: true })
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des quiz:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère un quiz spécifique par son ID */
  async getQuizById(quizId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          *,
          quiz_categories (
            id,
            name,
            description
          )
        `)
        .eq('id', quizId)
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la récupération du quiz:', error);
      return { success: false, error: error.message };
    }
  },

  /** Filtre les quiz par niveau de difficulté (beginner, intermediate, advanced) */
  async getQuizzesByLevel(level) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          *,
          quiz_categories (
            id,
            name,
            description
          )
        `)
        .eq('is_active', true)
        .eq('level', level)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des quiz par niveau:', error);
      return { success: false, error: error.message };
    }
  },

  // ========================================
  // QUESTIONS - Gestion des questions et réponses
  // ========================================

  /** Récupère toutes les questions d'un quiz donné */
  async getQuizQuestions(quizId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('quiz_questions')
        .select('*')
        .eq('quiz_id', quizId)
        .order('order_index', { ascending: true });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des questions:', error);
      return { success: false, error: error.message };
    }
  },

  /** Charge une question avec toutes ses réponses possibles */
  async getQuestionWithAnswers(questionId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('quiz_questions')
        .select(`
          *,
          quiz_answers (
            id,
            label,
            is_correct,
            feedback
          )
        `)
        .eq('id', questionId)
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la récupération de la question:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère uniquement les réponses d'une question (sans is_correct pour sécurité frontend) */
  async getQuestionAnswers(questionId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('quiz_answers')
        .select('id, question_id, label')
        .eq('question_id', questionId);

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des réponses:', error);
      return { success: false, error: error.message };
    }
  },

  // ========================================
  // SESSIONS - Suivi de la progression des utilisateurs
  // ========================================

  /** 
   * Créer une nouvelle session de quiz pour un utilisateur
   * Gère automatiquement le numéro de tentative (attempt_index)
   */
  async createQuizSession(userId, quizId) {
    try {
      const supabase = await getSupabaseClient();
      
      // Récupérer le dernier attempt_index pour incrémenter
      const { data: sessions, error: fetchError } = await supabase
        .from('user_quiz_sessions')
        .select('attempt_index')
        .eq('user_id', userId)
        .eq('quiz_id', quizId)
        .order('attempt_index', { ascending: false })
        .limit(1);

      if (fetchError) throw fetchError;

      const nextAttemptIndex = sessions && sessions.length > 0 
        ? sessions[0].attempt_index + 1 
        : 1;

      // Insertion de la nouvelle session
      const { data, error } = await supabase
        .from('user_quiz_sessions')
        .insert({
          user_id: userId,
          quiz_id: quizId,
          score: 0,
          duration_sec: 0,
          attempt_index: nextAttemptIndex,
          completed_at: null
        })
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la création de la session:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère une session spécifique avec les infos du quiz associé */
  async getSessionById(sessionId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_quiz_sessions')
        .select(`
          *,
          quizzes (*)
        `)
        .eq('id', sessionId)
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la récupération de la session:', error);
      return { success: false, error: error.message };
    }
  },

  /** Met à jour les données d'une session (score, durée, etc.) */
  async updateQuizSession(sessionId, updateData) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_quiz_sessions')
        .update(updateData)
        .eq('id', sessionId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la session:', error);
      return { success: false, error: error.message };
    }
  },

  /** Marque une session comme terminée avec le score final */
  async completeQuizSession(sessionId, score, durationSec) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_quiz_sessions')
        .update({
          score: score,
          duration_sec: durationSec,
          completed_at: new Date().toISOString()
        })
        .eq('id', sessionId)
        .select()
        .single();

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la complétion de la session:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère l'historique de toutes les sessions d'un utilisateur */
  async getUserSessions(userId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_quiz_sessions')
        .select(`
          *,
          quizzes (
            id,
            title,
            level,
            description
          )
        `)
        .eq('user_id', userId)
        .order('completed_at', { ascending: false });

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des sessions:', error);
      return { success: false, error: error.message };
    }
  },

  // ========================================
  // RÉPONSES - Sauvegarde des choix utilisateur
  // ========================================

  /** 
   * Sauvegarde une réponse d'utilisateur et vérifie sa validité
   * Retourne is_correct pour le feedback immédiat
   */
  async saveUserAnswer(sessionId, questionId, answerId) {
    try {
      const supabase = await getSupabaseClient();
      
      // Vérifier d'abord si la réponse est correcte
      const { data: answerData, error: answerError } = await supabase
        .from('quiz_answers')
        .select('is_correct')
        .eq('id', answerId)
        .single();

      if (answerError) throw answerError;

      // Enregistrer dans user_quiz_answers
      const { data, error } = await supabase
        .from('user_quiz_answers')
        .insert({
          session_id: sessionId,
          question_id: questionId,
          answer_id: answerId,
          is_correct: answerData.is_correct,
          answered_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      return { 
        success: true, 
        data,
        isCorrect: answerData.is_correct
      };
    } catch (error) {
      console.error('Erreur lors de la sauvegarde de la réponse:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupère toutes les réponses d'une session avec détails */
  async getSessionAnswers(sessionId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_quiz_answers')
        .select(`
          *,
          quiz_questions (
            id,
            question,
            explanation
          ),
          quiz_answers (
            id,
            label,
            is_correct,
            feedback
          )
        `)
        .eq('session_id', sessionId);

      if (error) throw error;
      return { success: true, data: data || [] };
    } catch (error) {
      console.error('Erreur lors de la récupération des réponses:', error);
      return { success: false, error: error.message };
    }
  },

  // ========================================
  // STATISTIQUES - Calculs et analyses
  // ========================================

  /** Calcule le score final d'une session (sur 10) */
  async calculateSessionScore(sessionId) {
    try {
      const answersResult = await this.getSessionAnswers(sessionId);
      if (!answersResult.success) throw new Error(answersResult.error);

      const answers = answersResult.data;
      if (answers.length === 0) return { success: true, score: 0, totalQuestions: 0 };

      const correctCount = answers.filter(a => a.is_correct).length;
      const totalQuestions = answers.length;
      const score = (correctCount / totalQuestions) * 10;

      return { 
        success: true, 
        score: Math.round(score * 10) / 10,
        correctCount,
        totalQuestions
      };
    } catch (error) {
      console.error('Erreur lors du calcul du score:', error);
      return { success: false, error: error.message };
    }
  },

  /** Génère les statistiques globales d'un utilisateur sur tous ses quiz */
  async getUserQuizStats(userId) {
    try {
      const sessionsResult = await this.getUserSessions(userId);
      if (!sessionsResult.success) throw new Error(sessionsResult.error);

      const sessions = sessionsResult.data.filter(s => s.completed_at !== null);
      
      if (sessions.length === 0) {
        return {
          success: true,
          stats: {
            totalQuizzes: 0,
            averageScore: 0,
            totalTime: 0,
            bestScore: 0,
            quizzesByLevel: {
              beginner: 0,
              intermediate: 0,
              advanced: 0
            }
          }
        };
      }

      const totalQuizzes = sessions.length;
      const averageScore = sessions.reduce((sum, s) => sum + parseFloat(s.score || 0), 0) / totalQuizzes;
      const totalTime = sessions.reduce((sum, s) => sum + parseInt(s.duration_sec || 0), 0);
      const bestScore = Math.max(...sessions.map(s => parseFloat(s.score || 0)));

      const quizzesByLevel = {
        beginner: sessions.filter(s => s.quizzes?.level === 'beginner').length,
        intermediate: sessions.filter(s => s.quizzes?.level === 'intermediate').length,
        advanced: sessions.filter(s => s.quizzes?.level === 'advanced').length
      };

      return {
        success: true,
        stats: {
          totalQuizzes,
          averageScore: Math.round(averageScore * 10) / 10,
          totalTime,
          bestScore,
          quizzesByLevel
        }
      };
    } catch (error) {
      console.error('Erreur lors du calcul des statistiques:', error);
      return { success: false, error: error.message };
    }
  },

  /** Calcule le score moyen d'un quiz (toutes tentatives confondues) */
  async getQuizAverageScore(quizId) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase
        .from('user_quiz_sessions')
        .select('score')
        .eq('quiz_id', quizId)
        .not('completed_at', 'is', null);

      if (error) throw error;

      if (!data || data.length === 0) {
        return { success: true, averageScore: 0, totalAttempts: 0 };
      }

      const totalScore = data.reduce((sum, s) => sum + parseFloat(s.score || 0), 0);
      const averageScore = totalScore / data.length;

      return {
        success: true,
        averageScore: Math.round(averageScore * 10) / 10,
        totalAttempts: data.length
      };
    } catch (error) {
      console.error('Erreur lors du calcul du score moyen:', error);
      return { success: false, error: error.message };
    }
  }
};

