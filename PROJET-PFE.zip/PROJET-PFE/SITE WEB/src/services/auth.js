import { getSupabaseClient } from '../config/supabase.js';

/**
 * Service d'authentification - 4students-NovaX
 * Gère l'inscription, connexion, déconnexion et réinitialisation de mot de passe
 */
export const authService = {
  /**
   * Inscription d'un nouvel utilisateur
   * Note: J'ai configuré la redirection vers confirm.html après validation de l'email
   */
  async signUp(email, password, name) {
    try {
      const supabase = await getSupabaseClient();
      
      // Construction de l'URL de redirection (gère différents chemins de l'app)
      let basePath = window.location.pathname;
      if (basePath.includes('/public/')) {
        basePath = basePath.substring(0, basePath.indexOf('/public/') + 7);
      } else if (basePath.includes('/src/')) {
        basePath = basePath.substring(0, basePath.indexOf('/src/')) + '/public';
      } else {
        basePath = '/public';
      }
      
      const redirectUrl = `${window.location.origin}${basePath}/confirm.html`;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: name
          },
          emailRedirectTo: redirectUrl
        }
      });

      if (error) throw error;
      
      // Si une session est retournée, c'est que l'email est déjà confirmé (ou confirmation désactivée)
      const isAutoConfirmed = !!data.session;
      
      return { success: true, data, isAutoConfirmed };
    } catch (error) {
      console.error('Erreur lors de l\'inscription:', error);
      return { success: false, error: error.message };
    }
  },

  /** Connexion avec email/mot de passe */
  async signIn(email, password) {
    try {
      const supabase = await getSupabaseClient();
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;
      return { success: true, data };
    } catch (error) {
      console.error('Erreur lors de la connexion:', error);
      return { success: false, error: error.message };
    }
  },

  /** Déconnexion de l'utilisateur */
  async signOut() {
    try {
      const supabase = await getSupabaseClient();
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Erreur lors de la déconnexion:', error);
      return { success: false, error: error.message };
    }
  },

  /** Récupérer l'utilisateur actuellement connecté */
  async getCurrentUser() {
    try {
      const supabase = await getSupabaseClient();
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) throw error;
      return user;
    } catch (error) {
      console.error('Erreur lors de la récupération de l\'utilisateur:', error);
      return null;
    }
  },

  /** Récupérer la session active */
  async getSession() {
    try {
      const supabase = await getSupabaseClient();
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      return session;
    } catch (error) {
      console.error('Erreur lors de la récupération de la session:', error);
      return null;
    }
  },

  /** 
   * Observer les changements d'auth (connexion/déconnexion)
   * Utile pour réagir en temps réel aux changements d'état
   */
  async onAuthStateChange(callback) {
    const supabase = await getSupabaseClient();
    return supabase.auth.onAuthStateChange((event, session) => {
      callback(event, session);
    });
  },

  /** Réinitialisation du mot de passe par email */
  async resetPassword(email) {
    try {
      const supabase = await getSupabaseClient();
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/public/login.html?reset=true`
      });
      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Erreur lors de la réinitialisation du mot de passe:', error);
      return { success: false, error: error.message };
    }
  }
};

