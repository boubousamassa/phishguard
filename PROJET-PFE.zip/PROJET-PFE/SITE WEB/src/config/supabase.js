import { createClient } from '@supabase/supabase-js';

/**
 * Module de configuration Supabase pour le projet 4students-NovaX
 * 
 * IMPORTANT pour l'équipe :
 * - Les identifiants Supabase sont stockés dans config.json (voir ce fichier)
 * - Pour configurer : récupérez votre URL et clé ANON depuis Settings > API sur Supabase
 * - Ne commitez jamais config.json avec les vraies clés !
 */

let config = null;
let supabaseClient = null;

/**
 * Chargement de la configuration depuis config.json
 * J'ai ajouté plusieurs chemins possibles pour gérer les imports depuis différents dossiers
 */
async function loadConfig() {
  if (config) {
    return config;
  }

  try {
    // Liste des chemins testés (selon d'où le fichier est appelé dans l'arborescence)
    const paths = [
      '/src/config/config.json',
      '../src/config/config.json',
      './src/config/config.json',
      '../config/config.json',
      '../../config/config.json',
      '../../src/config/config.json'
    ];
    
    let lastError = null;
    for (const path of paths) {
      try {
        const response = await fetch(path);
        if (response.ok) {
          config = await response.json();
          return config;
        }
      } catch (err) {
        lastError = err;
        continue;
      }
    }
    
    throw lastError || new Error('Impossible de charger la configuration');
  } catch (error) {
    console.error('❌ Erreur lors du chargement de la configuration:', error);
    // Fallback avec des valeurs placeholder (à remplacer dans config.json)
    return {
      SUPABASE_URL: 'https://votre-projet.supabase.co',
      SUPABASE_ANON_KEY: 'votre-clé-anon-publique'
    };
  }
}

/**
 * Initialisation du client Supabase
 * Note : le client est créé une seule fois (singleton) pour optimiser les performances
 */
async function initSupabase() {
  if (supabaseClient) {
    return supabaseClient;
  }

  const configData = await loadConfig();

  // Vérification de sécurité : warning si les clés par défaut sont toujours présentes
  if (!configData.SUPABASE_URL || !configData.SUPABASE_ANON_KEY || 
      configData.SUPABASE_URL.includes('votre-projet') || 
      configData.SUPABASE_ANON_KEY.includes('votre-clé')) {
    console.warn('⚠️ Attention: Les clés Supabase ne sont pas configurées.');
  }

  supabaseClient = createClient(configData.SUPABASE_URL, configData.SUPABASE_ANON_KEY);
  return supabaseClient;
}

/**
 * Fonction principale à utiliser dans l'application
 * Usage : const supabase = await getSupabaseClient();
 */
export async function getSupabaseClient() {
  return await initSupabase();
}
