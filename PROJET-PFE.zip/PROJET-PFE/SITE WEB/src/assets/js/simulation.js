/**
 * Page des simulations - 4students-NovaX
 * Gère les interactions avec les cartes de simulation (fonctionnalité à venir)
 */
import { requireAuth } from './auth-guard.js';
import { authService } from '../../services/auth.js';

document.addEventListener('DOMContentLoaded', async () => {
  // Vérification de l'authentification (redirection si non connecté)
  const user = await requireAuth();
  
  if (!user) {
    // Redirection en cours, arrêter l'exécution
    return;
  }
  
  updateHeaderForAuthenticatedUser(user);

  const buttons = document.querySelectorAll('[data-action]');

  buttons.forEach(button => {
    button.addEventListener('click', () => {
      const action = button.dataset.action;
      if (!action) return;

      switch (action) {
        case 'start-simulation':
          window.alert('La simulation éclair se prépare… NovaX vous notifie dès son lancement.');
          break;
        case 'schedule-session':
          window.alert('La planification arrivera prochainement. Restez connecté·e !');
          break;
        case 'view-details':
          window.alert('Briefing complet disponible bientôt. Merci pour votre patience.');
          break;
        case 'begin-track':
          window.alert('Ce parcours est en cours de finalisation. NovaX vous avertira dès son ouverture.');
          break;
        default:
          window.alert('Fonctionnalité à venir.');
      }
    });
  });
});

// ==================================
// Header pour utilisateur connecté
// ==================================
function updateHeaderForAuthenticatedUser(user) {
  const headerCta = document.querySelector('.site-header__cta');
  if (headerCta) {
    const userName = user.user_metadata?.name || user.email?.split('@')[0] || 'Utilisateur';
    headerCta.innerHTML = `
      <span class="session-chip">
        <span class="session-chip__status" aria-hidden="true"></span>
        Bonjour, ${userName} 👋
      </span>
      <a class="btn btn--ghost btn--small" href="#" id="logout-btn">Déconnexion</a>
    `;

    // Bouton de déconnexion
    document.getElementById('logout-btn')?.addEventListener('click', async (e) => {
      e.preventDefault();
      await authService.signOut();
      window.location.href = '../../public/login.html';
    });
  }
}

