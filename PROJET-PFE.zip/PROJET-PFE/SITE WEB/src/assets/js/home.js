/**
 * Page d'accueil - 4students-NovaX
 * Gère le scroll smooth et la navigation condensée
 */
document.querySelectorAll('[data-scroll]').forEach((trigger) => {
  trigger.addEventListener('click', (event) => {
    const target = trigger.getAttribute('data-scroll');
    const element = document.querySelector(target);

    if (element) {
      event.preventDefault();
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

const nav = document.querySelector('.top-nav');
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) {
        nav.classList.add('nav-condensed');
      } else {
        nav.classList.remove('nav-condensed');
      }
    });
  },
  { threshold: 0.1 }
);

observer.observe(document.querySelector('.hero'));

