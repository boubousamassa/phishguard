/**
 * Page des tips - 4students-NovaX
 * Conseils pratiques de cybersécurité avec sauvegarde en favoris
 */
import { requireAuth } from './auth-guard.js';
import { authService } from '../../services/auth.js';
import { userService } from '../../services/userService.js';

let currentUser = null;
let savedTips = new Set();

document.addEventListener('DOMContentLoaded', async () => {
  // Vérification de l'authentification (redirection si non connecté)
  currentUser = await requireAuth();
  
  if (!currentUser) {
    // Redirection en cours, arrêter l'exécution
    return;
  }
  
  updateHeaderForAuthenticatedUser(currentUser);
  await loadSavedTips(currentUser.id);

  // Chargement du catalogue de tips
  await loadAllTips();

  // Système de filtres par catégorie
  const filters = document.querySelectorAll('.tips-filters .filter');
  const cards = document.querySelectorAll('.tip-card');

  filters.forEach(filter => {
    filter.addEventListener('click', () => {
      const category = filter.dataset.filter ?? 'all';
      filters.forEach(btn => btn.classList.toggle('is-active', btn === filter));

      cards.forEach(card => {
        const matches = category === 'all' || card.dataset.category === category;
        card.toggleAttribute('hidden', !matches);
      });
    });
  });
});

// ==================================
// Header pour utilisateur connecté
// ==================================
function updateHeaderForAuthenticatedUser(user) {
  const headerCta = document.querySelector('.site-header__cta');
  if (headerCta) {
    const userName = user.user_metadata?.name || user.email?.split('@')[0] || 'Utilisateur';
    headerCta.innerHTML = `
      <span class="session-chip">
        <span class="session-chip__status" aria-hidden="true"></span>
        Bonjour, ${userName} 👋
      </span>
      <a class="btn btn--ghost btn--small" href="#" id="logout-btn">Déconnexion</a>
    `;

    // Bouton de déconnexion
    document.getElementById('logout-btn')?.addEventListener('click', async (e) => {
      e.preventDefault();
      await authService.signOut();
      window.location.href = '../../public/login.html';
    });
  }
}

// Chargement des tips sauvegardés en favoris
async function loadSavedTips(userId) {
  try {
    const result = await userService.getUserSavedTips(userId);
    if (result.success) {
      savedTips = new Set(result.data.map(item => item.tip_id));
    }
  } catch (error) {
    // Mode dégradé si la table n'existe pas encore
    console.warn('⚠️ Sauvegarde tips désactivée - migration DB en attente');
    savedTips = new Set();
  }
}

// ==================================
// Chargement du catalogue de tips
// ==================================
async function loadAllTips() {
  try {
    const result = await userService.getAllTips();
    
    if (result.success && result.data && result.data.length > 0) {
      updateTipsGrid(result.data);
    }
  } catch (error) {
    console.error('Erreur lors du chargement des tips:', error);
  }
}

// ==================================
// Génération de la grille de tips
// ==================================
function updateTipsGrid(tips) {
  const tipsGrid = document.querySelector('.tips-grid');
  if (!tipsGrid || tips.length === 0) return;

  tipsGrid.innerHTML = tips.map(tip => {
    const isSaved = savedTips.has(tip.id);
    const categoryLabel = getCategoryIcon(tip.category);
    
    return `
      <article class="tip-card" data-category="${tip.category || 'phishing'}">
        <header>
          <span aria-hidden="true">${categoryLabel}</span>
          <h2>${tip.title}</h2>
        </header>
        <p>${tip.content}</p>
        <footer>
          <span>Impact : <strong>${tip.impact || 'Moyen'}</strong></span>
          <button class="btn btn--ghost btn--small ${isSaved ? 'is-saved' : ''}" 
                  type="button" 
                  data-action="save-tip" 
                  data-tip-id="${tip.id}">
            ${isSaved ? 'Enregistré' : 'Enregistrer'}
          </button>
        </footer>
      </article>
    `;
  }).join('');

  // Attachement des événements sur les boutons de sauvegarde
  const saveButtons = tipsGrid.querySelectorAll('[data-action="save-tip"]');
  saveButtons.forEach(button => {
    button.addEventListener('click', async () => {
      if (!currentUser) {
        window.alert('Veuillez vous connecter pour sauvegarder des tips.');
        return;
      }

      const tipId = button.dataset.tipId;
      const isSaved = savedTips.has(tipId);

      if (isSaved) {
        // Retrait des favoris
        const result = await userService.unsaveTip(currentUser.id, tipId);
        if (result.success) {
          savedTips.delete(tipId);
          button.classList.remove('is-saved');
          button.textContent = 'Enregistrer';
        }
      } else {
        // Ajout aux favoris
        const result = await userService.saveTip(currentUser.id, tipId);
        if (result.success) {
          savedTips.add(tipId);
          button.classList.add('is-saved');
          button.textContent = 'Enregistré';
        }
      }
    });
  });
}

// Helper : icônes par catégorie
function getCategoryIcon(category) {
  const icons = {
    'phishing': '📧',
    'password': '🔐',
    'privacy': '🕶️',
    'devices': '💻'
  };
  return icons[category] || '💡';
}
