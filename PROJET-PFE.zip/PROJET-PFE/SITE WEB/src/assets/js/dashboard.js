/**
 * Dashboard principal - 4students-NovaX
 * Affiche les stats, progression, achievements, et activités récentes
 */
import { requireAuth } from './auth-guard.js';
import { authService } from '../../services/auth.js';
import { userService } from '../../services/userService.js';
import { notificationSystem } from './notifications.js';
import { onboardingSystem } from './onboarding.js';
import { personalizationSystem } from './personalization.js';

document.addEventListener('DOMContentLoaded', async () => {
  // Vérification de l'authentification (redirection si non connecté)
  const user = await requireAuth();
  
  if (!user) {
    // Redirection en cours, arrêter l'exécution
    return;
  }

  // Charger et appliquer les préférences de personnalisation
  const preferences = await personalizationSystem.loadUserPreferences();
  if (preferences) {
    personalizationSystem.applyPreferences(preferences);
  }

  // Vérifier et démarrer l'onboarding si nécessaire
  const needsOnboarding = await onboardingSystem.checkOnboardingStatus(user.id);
  if (needsOnboarding) {
    // Définir les étapes de l'onboarding
    onboardingSystem.setSteps([
      {
        icon: '🎓',
        title: 'Bienvenue sur 4Students !',
        description: 'Découvrez comment protéger votre vie numérique avec des quiz interactifs et des simulations réalistes.'
      },
      {
        icon: '🎯',
        title: 'Testez vos connaissances',
        description: 'Participez à des quiz sur le phishing, les mots de passe et la sécurité en ligne. Gagnez des XP et montez de niveau !'
      },
      {
        icon: '🛡️',
        title: 'Lancez des simulations',
        description: 'Mettez-vous dans des situations réelles et apprenez à détecter les menaces avant qu\'il ne soit trop tard.'
      },
      {
        icon: '🏆',
        title: 'Débloquez des badges',
        description: 'Complétez des défis pour débloquer des badges exclusifs et suivre votre progression.'
      },
      {
        icon: '✨',
        title: 'Personnalisez votre expérience',
        description: 'Choisissez votre mascotte et votre thème de couleur pour rendre votre parcours unique !'
      }
    ]);
    
    // Démarrer l'onboarding après un court délai
    setTimeout(() => {
      onboardingSystem.startOnboarding();
    }, 1000);
  }

  // Affichage du nom de l'utilisateur dans le header
  const sessionChip = document.querySelector('.session-chip');
  if (sessionChip) {
    const userName = user.user_metadata?.name || user.email?.split('@')[0] || 'Invité';
    sessionChip.innerHTML = `
      <span class="session-chip__status" aria-hidden="true"></span>
      Bonjour, ${userName} <span data-mascot>👋</span>
    `;
  }

  // Titre personnalisé du dashboard
  const dashboardTitle = document.querySelector('.dashboard-hero h1');
  if (dashboardTitle) {
    const userName = user.user_metadata?.name || user.email?.split('@')[0] || 'Invité';
    dashboardTitle.innerHTML = `Bonjour, ${userName} <span data-mascot>👋</span>`;
  }

  // Appliquer les préférences maintenant que le DOM est prêt
  if (preferences) {
    personalizationSystem.applyPreferences(preferences);
  }

  // Bouton de personnalisation
  const personalizationBtn = document.getElementById('personalization-btn');
  if (personalizationBtn) {
    personalizationBtn.addEventListener('click', () => {
      personalizationSystem.openPersonalizationModal();
    });
  }

  // Bouton de déconnexion
  const logoutBtn = document.querySelector('a[href*="login.html"]');
  if (logoutBtn && logoutBtn.textContent.includes('Déconnexion')) {
    logoutBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      await authService.signOut();
      window.location.href = '../../public/login.html';
    });
  }

  // Chargement des données utilisateur (niveau, XP, stats)
  await loadUserData(user.id);

  // Chargement de l'historique d'activités
  await loadRecentActivities(user.id);

  // Vérification des achievements à débloquer
  await checkForNewAchievements(user.id);

  // Adaptation des CTA selon l'expérience utilisateur
  await updateCtaButtons(user.id);

  // ==================================
  // Filtres et animations des vidéos
  // ==================================
  const filters = document.querySelectorAll('.videos .filter');
  const videos = document.querySelectorAll('.video-card');
  const progressBar = document.querySelector('.progress-card__bar-fill');
  const progressCard = document.querySelector('.progress-card__bar');

  filters.forEach((filter) => {
    filter.addEventListener('click', () => {
      const target = filter.dataset.filter ?? 'all';

      // Mise à jour visuelle des filtres actifs
      filters.forEach((btn) => btn.classList.toggle('is-active', btn === filter));

      // Affichage/masquage avec animation
      videos.forEach((video) => {
        const level = video.dataset.level ?? 'all';
        const shouldShow = target === 'all' || level === target;
        
        if (shouldShow) {
          // Animation d'apparition
          video.style.display = 'grid';
          video.offsetHeight; // Force reflow
          video.style.opacity = '1';
          video.style.transform = 'scale(1)';
        } else {
          // Animation de disparition
          video.style.opacity = '0';
          video.style.transform = 'scale(0.95)';
          // Masquage complet après transition
          setTimeout(() => {
            if (video.style.opacity === '0') {
              video.style.display = 'none';
            }
          }, 300);
        }
      });
    });
  });

  // Note: animation de la barre de progression désactivée pour des raisons de performance

  // Actions diverses du dashboard
  const actions = document.querySelectorAll('[data-action]');
  actions.forEach((action) => {
    action.addEventListener('click', (event) => {
      const intent = action.dataset.action;
      if (!intent) return;
      
      // resume-quiz a son propre gestionnaire
      if (intent === 'resume-quiz') return;
      
      event.preventDefault();
      window.alert(`Fonction "${intent}" en cours de conception. Restez connecté·e !`);
    });
  });
});

// ==================================
// Chargement des données utilisateur
// ==================================
async function loadUserData(userId) {
  try {
    // Récupération du niveau utilisateur
    const levelResult = await userService.getUserLevel(userId);
    if (levelResult.success && levelResult.data) {
      updateUserLevelDisplay(levelResult.data);
    } else {
      // Création d'un niveau par défaut pour les nouveaux utilisateurs
      const defaultLevel = await userService.upsertUserLevel(userId, {
        level: 1,
        xp: 0,
        total_points: 0
      });
      if (defaultLevel.success && defaultLevel.data) {
        updateUserLevelDisplay(defaultLevel.data);
      }
    }

    // Chargement des sessions de quiz
    const quizResult = await userService.getUserQuizSessions(userId);
    if (quizResult.success) {
      updateQuizStats(quizResult.data);
    }

    // Chargement des achievements
    const achievementsResult = await userService.getAllAchievementsWithStatus(userId);
    if (achievementsResult.success) {
      updateAchievementsDisplay(achievementsResult.data);
    }

    // Chargement des vidéos (pour mise à jour si nécessaire)
    const videosResult = await userService.getUserVideos(userId);
    if (videosResult.success) {
      // Traitement des vidéos si nécessaire
    }
  } catch (error) {
    console.error('Erreur lors du chargement des données utilisateur:', error);
  }
}

// ==================================
// Affichage du niveau et XP
// ==================================
function updateUserLevelDisplay(levelData) {
  const XP_PER_LEVEL = 100;
  
  // Mise à jour de la carte de niveau (icône 📈)
  const statCards = document.querySelectorAll('.stat-card');
  statCards.forEach(card => {
    const icon = card.querySelector('.stat-card__icon');
    if (icon && icon.textContent.includes('📈')) {
      const levelValue = card.querySelector('.stat-card__value');
      if (levelValue) {
        levelValue.textContent = levelData.level || 1;
      }
      const levelMeta = card.querySelector('.stat-card__meta');
      if (levelMeta) {
        const levelName = getLevelName(levelData.level || 1);
        levelMeta.textContent = levelName;
      }
    }
    // Carte des points totaux (icône 🏆)
    if (icon && icon.textContent.includes('🏆')) {
      const totalPoints = card.querySelector('.stat-card__value');
      if (totalPoints) {
        totalPoints.textContent = levelData.total_points || 0;
      }
    }
  });

  // Barre de progression vers le prochain niveau
  const progressBar = document.querySelector('.progress-card__bar-fill');
  const progressScore = document.querySelector('.progress-card__score');
  const progressNote = document.querySelector('.progress-card__note');
  const progressTitle = document.querySelector('.progress-card h2');
  
  if (progressBar && levelData.xp !== undefined) {
    // Calcul du pourcentage dans le niveau actuel
    const xpInCurrentLevel = levelData.xp % XP_PER_LEVEL;
    const percentage = (xpInCurrentLevel / XP_PER_LEVEL) * 100;
    const xpNeeded = XP_PER_LEVEL - xpInCurrentLevel;
    const nextLevel = (levelData.level || 1) + 1;
    
    progressBar.style.width = `${percentage}%`;
    
    if (progressScore) {
      progressScore.textContent = `${Math.round(percentage)}%`;
    }
    
    if (progressTitle) {
      progressTitle.textContent = `Progression vers le niveau ${nextLevel}`;
    }
    
    if (progressNote) {
      progressNote.innerHTML = `Plus que <strong>${xpNeeded} XP</strong> pour passer au niveau suivant ! <br><small>${xpInCurrentLevel}/${XP_PER_LEVEL} XP</small>`;
    }
  }
}

// Helper : traduction des niveaux en noms
function getLevelName(level) {
  const levelNames = {
    1: 'Débutant',
    2: 'Novice',
    3: 'Expert Junior',
    4: 'Expert',
    5: 'Maître',
    6: 'Grand Maître',
    7: 'Légende'
  };
  return levelNames[level] || `Niveau ${level}`;
}

// ==================================
// Statistiques des quiz
// ==================================
function updateQuizStats(quizSessions) {
  const statCards = document.querySelectorAll('.stat-card');
  statCards.forEach(card => {
    const icon = card.querySelector('.stat-card__icon');
    // Carte: quiz complétés (icône 📘)
    if (icon && icon.textContent.includes('📘')) {
      const totalQuizzes = card.querySelector('.stat-card__value');
      if (totalQuizzes) {
        totalQuizzes.textContent = quizSessions.length || 0;
      }
    }
    // Carte: score moyen (icône ⭐)
    if (icon && icon.textContent.includes('⭐')) {
      const avgScore = card.querySelector('.stat-card__value');
      if (quizSessions.length > 0) {
        const totalScore = quizSessions.reduce((sum, session) => sum + parseFloat(session.score || 0), 0);
        const averageScore = (totalScore / quizSessions.length).toFixed(1);
        if (avgScore) {
          avgScore.innerHTML = `${averageScore}<span>/10</span>`;
        }
      } else if (avgScore) {
        // Valeur par défaut si aucun quiz
        avgScore.innerHTML = `0<span>/10</span>`;
      }
    }
  });
}

// ==================================
// Achievements (badges)
// ==================================
function updateAchievementsDisplay(achievementsData) {
  const achievementsHeader = document.querySelector('.achievements header p');
  const achievementsGrid = document.querySelector('.achievements__grid');
  
  if (!achievementsGrid) return;
  
  // Gestion du cas vide
  if (!achievementsData || achievementsData.length === 0) {
    achievementsGrid.innerHTML = '<p style="padding: 20px; text-align: center; color: var(--text-muted);">Aucun badge disponible</p>';
    if (achievementsHeader) {
      achievementsHeader.textContent = '0 / 0 badges débloqués';
    }
    return;
  }
  
  const unlockedCount = achievementsData.filter(a => a.unlocked).length;
  const totalCount = achievementsData.length;
  
  if (achievementsHeader) {
    achievementsHeader.textContent = `${unlockedCount} / ${totalCount} badges débloqués`;
  }
  
  // Génération HTML des badges
  achievementsGrid.innerHTML = achievementsData.map(achievement => `
    <article class="badge ${achievement.unlocked ? 'is-unlocked' : ''}" 
             title="${achievement.description || achievement.name}">
      <span class="badge__icon" aria-hidden="true">${achievement.icon || '🎯'}</span>
      <strong>${achievement.name}</strong>
      <small>${achievement.unlocked ? 'Complété' : 'À débloquer'}</small>
    </article>
  `).join('');
}

// ==================================
// Activités récentes
// ==================================
async function loadRecentActivities(userId) {
  const activityList = document.querySelector('.activity-list');
  
  try {
    const activities = [];
    
    // Chargement des quiz complétés
    try {
      const quizResult = await userService.getUserQuizSessions(userId);
      if (quizResult.success && quizResult.data && Array.isArray(quizResult.data)) {
        quizResult.data.forEach(session => {
          if (session.completed_at) {
            activities.push({
              type: 'quiz',
              icon: '🎯',
              title: session.quizzes?.title || 'Quiz complété',
              subtitle: `Score : ${session.score}/10`,
              date: new Date(session.completed_at)
            });
          }
        });
      }
    } catch (error) {
      console.error('Erreur chargement quiz:', error);
    }
    
    // Chargement des vidéos visionnées
    try {
      const videosResult = await userService.getUserVideos(userId);
      if (videosResult.success && videosResult.data && Array.isArray(videosResult.data)) {
        videosResult.data.filter(v => v.completed).forEach(video => {
          if (video.updated_at) {
            activities.push({
              type: 'video',
              icon: '🎥',
              title: video.videos?.title || 'Vidéo visionnée',
              subtitle: 'Complétée',
              date: new Date(video.updated_at)
            });
          }
        });
      }
    } catch (error) {
      console.error('Erreur chargement vidéos:', error);
    }
    
    // Chargement des tips sauvegardés
    try {
      const tipsResult = await userService.getUserSavedTips(userId);
      if (tipsResult.success && tipsResult.data && Array.isArray(tipsResult.data)) {
        tipsResult.data.forEach(tip => {
          if (tip.saved_at) {
            activities.push({
              type: 'tip',
              icon: '💡',
              title: tip.tips?.title || 'Tip sauvegardé',
              subtitle: 'Ajouté à vos favoris',
              date: new Date(tip.saved_at)
            });
          }
        });
      }
    } catch (error) {
      console.error('Erreur chargement tips:', error);
    }
    
    // Tri chronologique inversé (plus récent en haut)
    activities.sort((a, b) => b.date - a.date);
    const recentActivities = activities.slice(0, 3);
    
    // Affichage HTML
    if (activityList) {
      if (recentActivities.length > 0) {
        activityList.innerHTML = recentActivities.map(activity => `
          <li>
            <span class="activity-icon" aria-hidden="true">${activity.icon}</span>
            <div>
              <strong>${activity.title}</strong>
              <span>${activity.subtitle} — ${formatDate(activity.date)}</span>
            </div>
          </li>
        `).join('');
      } else {
        // Message si aucune activité
        activityList.innerHTML = `
          <li>
            <span class="activity-icon" aria-hidden="true">🎓</span>
            <div>
              <strong>Aucune activité récente</strong>
              <span>Commencez un quiz pour voir votre progression !</span>
            </div>
          </li>
        `;
      }
    }
  } catch (error) {
    console.error('Erreur lors du chargement des activités:', error);
    // Message d'erreur convivial
    if (activityList) {
      activityList.innerHTML = `
        <li>
          <span class="activity-icon" aria-hidden="true">⚠️</span>
          <div>
            <strong>Erreur de chargement</strong>
            <span>Impossible de charger vos activités récentes</span>
          </div>
        </li>
      `;
    }
  }
}

// Helper : formatage des dates en français
function formatDate(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return "aujourd'hui";
  if (diffDays === 1) return "hier";
  if (diffDays < 7) return `il y a ${diffDays} jours`;
  return date.toLocaleDateString('fr-FR');
}

// ==================================
// Vérification des achievements
// ==================================
async function checkForNewAchievements(userId) {
  try {
    const result = await userService.checkAchievementConditions(userId);
    if (result.success && result.notifications) {
      // Les notifications seront gérées par le système de notifications
    }
  } catch (error) {
    console.error('Erreur lors de la vérification des achievements:', error);
  }
}

// ==================================
// Adaptation des boutons CTA
// ==================================
async function updateCtaButtons(userId) {
  try {
    const startQuizBtn = document.getElementById('start-quiz-btn');
    const resumeQuizBtn = document.getElementById('resume-quiz-btn');
    const heroParagraph = document.querySelector('.dashboard-hero p');
    
    if (!startQuizBtn || !resumeQuizBtn) return;
    
    // Chargement de l'historique des quiz
    const quizResult = await userService.getUserQuizSessions(userId);
    
    if (quizResult.success && quizResult.data && quizResult.data.length > 0) {
      // Utilisateur expérimenté : afficher "Reprendre"
      startQuizBtn.style.display = 'none';
      resumeQuizBtn.style.display = 'inline-flex';
      
      // Message adapté pour utilisateur récurrent
      if (heroParagraph) {
        heroParagraph.textContent = 'Continuez votre apprentissage en cybersécurité à votre rythme. Suivez votre progression, testez vos réflexes et déclenchez NovaX lorsque vous en avez besoin.';
      }
      
      // Redirection vers le catalogue de quiz
      resumeQuizBtn.addEventListener('click', () => {
        window.location.href = '../components/quiz.html';
      });
    } else {
      // Nouvel utilisateur : afficher "Commencer"
      startQuizBtn.style.display = 'inline-flex';
      resumeQuizBtn.style.display = 'none';
      
      // Message adapté pour nouvel arrivant
      if (heroParagraph) {
        heroParagraph.textContent = 'Bienvenue dans votre espace personnel ! Commencez votre formation en cybersécurité avec des quiz interactifs, des simulations réalistes et des conseils pratiques.';
      }
    }
  } catch (error) {
    console.error('Erreur lors de la mise à jour des boutons CTA:', error);
    // Par défaut : afficher le bouton pour nouveaux utilisateurs
    const startQuizBtn = document.getElementById('start-quiz-btn');
    const resumeQuizBtn = document.getElementById('resume-quiz-btn');
    if (startQuizBtn) startQuizBtn.style.display = 'inline-flex';
    if (resumeQuizBtn) resumeQuizBtn.style.display = 'none';
  }
}

