/**
 * Système de personnalisation - 4students-NovaX
 * Gère les avatars, mascottes et thèmes de couleur
 */
import { authService } from '../../services/auth.js';

class PersonalizationSystem {
  constructor() {
    this.mascots = [
      { id: 'shield', emoji: '🛡️', name: 'Shield', description: 'Le protecteur' },
      { id: 'fox', emoji: '🦊', name: 'Fox', description: 'Rusé et vigilant' },
      { id: 'owl', emoji: '🦉', name: 'Owl', description: 'Sage et observateur' },
      { id: 'eagle', emoji: '🦅', name: 'Eagle', description: 'Vue perçante' },
      { id: 'lion', emoji: '🦁', name: 'Lion', description: 'Courageux et fort' },
      { id: 'tiger', emoji: '🐅', name: 'Tiger', description: 'Agile et rapide' }
    ];

    this.themes = [
      { id: 'default', name: 'Par défaut', colors: { primary: '#3635ff', secondary: '#5a7bff' } },
      { id: 'ocean', name: 'Océan', colors: { primary: '#0ea5e9', secondary: '#06b6d4' } },
      { id: 'forest', name: 'Forêt', colors: { primary: '#10b981', secondary: '#059669' } },
      { id: 'sunset', name: 'Coucher de soleil', colors: { primary: '#f59e0b', secondary: '#f97316' } },
      { id: 'purple', name: 'Violet', colors: { primary: '#8b5cf6', secondary: '#a78bfa' } },
      { id: 'rose', name: 'Rose', colors: { primary: '#ec4899', secondary: '#f472b6' } }
    ];
  }

  /**
   * Charge les préférences de personnalisation de l'utilisateur
   */
  async loadUserPreferences() {
    try {
      const user = await authService.getCurrentUser();
      if (!user) return null;

      const preferences = user.user_metadata?.personalization || {
        avatar: null,
        mascot: 'shield',
        theme: 'default'
      };

      return preferences;
    } catch (error) {
      console.error('Erreur lors du chargement des préférences:', error);
      return null;
    }
  }

  /**
   * Sauvegarde les préférences de personnalisation
   */
  async savePreferences(preferences) {
    try {
      const user = await authService.getCurrentUser();
      if (!user) throw new Error('Utilisateur non connecté');

      const { getSupabaseClient } = await import('../../config/supabase.js');
      const supabase = await getSupabaseClient();
      
      const currentMetadata = user.user_metadata || {};
      const updatedMetadata = {
        ...currentMetadata,
        personalization: {
          ...currentMetadata.personalization,
          ...preferences
        }
      };

      const { error } = await supabase.auth.updateUser({
        data: updatedMetadata
      });

      if (error) throw error;

      // Appliquer immédiatement les changements
      this.applyPreferences(preferences);
      
      return { success: true };
    } catch (error) {
      console.error('Erreur lors de la sauvegarde des préférences:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Applique les préférences à l'interface
   */
  applyPreferences(preferences) {
    // Appliquer le thème
    if (preferences.theme) {
      this.applyTheme(preferences.theme);
    }

    // Appliquer la mascotte (peut être affichée dans le header ou dashboard)
    if (preferences.mascot) {
      this.displayMascot(preferences.mascot);
    }

    // Appliquer l'avatar (peut être affiché dans le header)
    if (preferences.avatar) {
      this.displayAvatar(preferences.avatar);
    }
  }

  /**
   * Applique un thème de couleur
   */
  applyTheme(themeId) {
    const theme = this.themes.find(t => t.id === themeId) || this.themes[0];
    
    // Appliquer les couleurs via CSS variables
    const root = document.documentElement;
    root.style.setProperty('--color-primary', theme.colors.primary);
    root.style.setProperty('--color-primary-dark', this.darkenColor(theme.colors.primary));
    
    // Sauvegarder dans localStorage pour persistance
    localStorage.setItem('user-theme', themeId);
  }

  /**
   * Assombrit une couleur
   */
  darkenColor(color) {
    // Conversion hex simple vers RGB, assombrir, puis retour en hex
    const hex = color.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    
    const newR = Math.max(0, r - 30).toString(16).padStart(2, '0');
    const newG = Math.max(0, g - 30).toString(16).padStart(2, '0');
    const newB = Math.max(0, b - 30).toString(16).padStart(2, '0');
    
    return `#${newR}${newG}${newB}`;
  }

  /**
   * Affiche la mascotte
   */
  displayMascot(mascotId) {
    const mascot = this.mascots.find(m => m.id === mascotId) || this.mascots[0];
    
    // Mettre à jour les éléments qui affichent la mascotte
    const mascotElements = document.querySelectorAll('[data-mascot]');
    mascotElements.forEach(el => {
      el.textContent = mascot.emoji;
      el.title = mascot.name;
    });
  }

  /**
   * Affiche l'avatar
   */
  displayAvatar(avatarData) {
    // Si c'est une URL, l'utiliser directement
    // Sinon, utiliser un avatar généré
    const avatarElements = document.querySelectorAll('[data-avatar]');
    avatarElements.forEach(el => {
      if (avatarData.startsWith('http')) {
        el.style.backgroundImage = `url(${avatarData})`;
        el.style.backgroundSize = 'cover';
        el.style.backgroundPosition = 'center';
      } else {
        // Avatar par défaut avec initiales ou emoji
        el.textContent = avatarData;
      }
    });
  }

  /**
   * Ouvre le modal de personnalisation
   */
  openPersonalizationModal() {
    this.createPersonalizationModal();
  }

  /**
   * Crée le modal de personnalisation
   */
  async createPersonalizationModal() {
    // Supprimer le modal existant
    const existing = document.getElementById('personalization-modal');
    if (existing) existing.remove();

    const preferences = await this.loadUserPreferences() || {
      avatar: null,
      mascot: 'shield',
      theme: 'default'
    };

    const modal = document.createElement('div');
    modal.id = 'personalization-modal';
    modal.className = 'personalization-modal';
    
    modal.innerHTML = `
      <div class="personalization-modal-overlay"></div>
      <div class="personalization-modal-content">
        <button class="personalization-modal-close" aria-label="Fermer">×</button>
        <h2>Personnalisez votre expérience</h2>
        
        <div class="personalization-section">
          <h3>Choisissez votre mascotte</h3>
          <div class="mascot-grid">
            ${this.mascots.map(mascot => `
              <button class="mascot-option ${preferences.mascot === mascot.id ? 'is-selected' : ''}" 
                      data-mascot-id="${mascot.id}">
                <span class="mascot-emoji">${mascot.emoji}</span>
                <span class="mascot-name">${mascot.name}</span>
                <span class="mascot-description">${mascot.description}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <div class="personalization-section">
          <h3>Choisissez votre thème</h3>
          <div class="theme-grid">
            ${this.themes.map(theme => `
              <button class="theme-option ${preferences.theme === theme.id ? 'is-selected' : ''}" 
                      data-theme-id="${theme.id}"
                      style="--theme-primary: ${theme.colors.primary}; --theme-secondary: ${theme.colors.secondary};">
                <span class="theme-preview" style="background: linear-gradient(135deg, ${theme.colors.primary}, ${theme.colors.secondary});"></span>
                <span class="theme-name">${theme.name}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <div class="personalization-actions">
          <button class="btn btn--primary personalization-save">Enregistrer</button>
          <button class="btn btn--ghost personalization-cancel">Annuler</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Event listeners
    const overlay = modal.querySelector('.personalization-modal-overlay');
    const closeBtn = modal.querySelector('.personalization-modal-close');
    const cancelBtn = modal.querySelector('.personalization-cancel');
    const saveBtn = modal.querySelector('.personalization-save');

    const closeModal = () => {
      modal.classList.remove('is-visible');
      setTimeout(() => modal.remove(), 300);
    };

    overlay.addEventListener('click', closeModal);
    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);

    // Sélection de mascotte
    modal.querySelectorAll('.mascot-option').forEach(btn => {
      btn.addEventListener('click', () => {
        modal.querySelectorAll('.mascot-option').forEach(b => b.classList.remove('is-selected'));
        btn.classList.add('is-selected');
      });
    });

    // Sélection de thème
    modal.querySelectorAll('.theme-option').forEach(btn => {
      btn.addEventListener('click', () => {
        modal.querySelectorAll('.theme-option').forEach(b => b.classList.remove('is-selected'));
        btn.classList.add('is-selected');
      });
    });

    // Sauvegarde
    saveBtn.addEventListener('click', async () => {
      const selectedMascot = modal.querySelector('.mascot-option.is-selected')?.dataset.mascotId;
      const selectedTheme = modal.querySelector('.theme-option.is-selected')?.dataset.themeId;

      if (selectedMascot && selectedTheme) {
        await this.savePreferences({
          mascot: selectedMascot,
          theme: selectedTheme
        });
        closeModal();
      }
    });

    // Animation d'entrée
    setTimeout(() => {
      modal.classList.add('is-visible');
    }, 10);
  }
}

export const personalizationSystem = new PersonalizationSystem();

