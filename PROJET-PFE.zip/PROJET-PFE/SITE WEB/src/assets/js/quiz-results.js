/**
 * Page de résultats de quiz - 4students-NovaX
 * Affiche le score, les statistiques et le détail des réponses
 */
import { requireAuth } from './auth-guard.js';
import { authService } from '../../services/auth.js';
import { quizService } from '../../services/quizService.js';

// État des résultats
const resultsState = {
  user: null,
  sessionId: null,
  session: null,
  answers: [],
  quiz: null
};

// Initialisation
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Vérifier l'authentification (redirection si non connecté)
    resultsState.user = await requireAuth();
    
    if (!resultsState.user) {
      // Redirection en cours, arrêter l'exécution
      return;
    }

    // Mettre à jour le header
    updateHeader();

    // Récupérer l'ID de la session depuis l'URL
    const urlParams = new URLSearchParams(window.location.search);
    resultsState.sessionId = urlParams.get('session');

    if (!resultsState.sessionId) {
      showError('Aucune session trouvée.');
      return;
    }

    // Charger les résultats
    await loadResults();
  } catch (error) {
    console.error('Erreur lors de l\'initialisation:', error);
    showError('Une erreur est survenue lors du chargement.');
  }
});

// Mettre à jour le header
function updateHeader() {
  const userName = resultsState.user.user_metadata?.name || resultsState.user.email?.split('@')[0] || 'Utilisateur';
  const userNameElement = document.getElementById('user-name');
  if (userNameElement) {
    userNameElement.textContent = userName;
  }

  // Gérer la déconnexion
  document.getElementById('logout-btn')?.addEventListener('click', async (e) => {
    e.preventDefault();
    await authService.signOut();
    window.location.href = '../../public/login.html';
  });
}

// Charger les résultats
async function loadResults() {
  try {
    // Récupérer la session
    const sessionResult = await quizService.getSessionById(resultsState.sessionId);
    if (!sessionResult.success) {
      throw new Error(sessionResult.error);
    }
    resultsState.session = sessionResult.data;
    resultsState.quiz = sessionResult.data.quizzes;

    // Récupérer les réponses
    const answersResult = await quizService.getSessionAnswers(resultsState.sessionId);
    if (!answersResult.success) {
      throw new Error(answersResult.error);
    }
    resultsState.answers = answersResult.data;

    // Récupérer le score moyen du quiz
    const avgScoreResult = await quizService.getQuizAverageScore(resultsState.quiz.id);
    const averageScore = avgScoreResult.success ? avgScoreResult.averageScore : 0;

    // Afficher les résultats
    displayResults(averageScore);
  } catch (error) {
    console.error('Erreur lors du chargement des résultats:', error);
    showError(error.message);
  }
}

// Afficher les résultats
function displayResults(averageScore) {
  // Masquer le chargement
  document.getElementById('quiz-loading').style.display = 'none';
  document.getElementById('results-content').style.display = 'block';

  const score = parseFloat(resultsState.session.score || 0);
  const correctCount = resultsState.answers.filter(a => a.is_correct).length;
  const totalQuestions = resultsState.answers.length;
  const durationSec = parseInt(resultsState.session.duration_sec || 0);

  // Déterminer le message et l'icône selon le score
  let icon = '🎉';
  let title = 'Félicitations !';
  let subtitle = 'Excellent travail !';

  if (score >= 8) {
    icon = '🎉';
    title = 'Félicitations !';
    subtitle = 'Excellent travail !';
  } else if (score >= 6) {
    icon = '👏';
    title = 'Bien joué !';
    subtitle = 'Vous êtes sur la bonne voie !';
  } else if (score >= 4) {
    icon = '💪';
    title = 'Continuez comme ça !';
    subtitle = 'Vous progressez !';
  } else {
    icon = '📚';
    title = 'N\'abandonnez pas !';
    subtitle = 'La pratique mène à la perfection !';
  }

  document.getElementById('result-icon').textContent = icon;
  document.getElementById('result-title').textContent = title;
  document.getElementById('result-subtitle').textContent = subtitle;

  // Afficher le score avec animation
  animateScore(score);

  // Afficher les statistiques
  document.getElementById('correct-count').textContent = `${correctCount}/${totalQuestions}`;
  
  const minutes = Math.floor(durationSec / 60);
  const seconds = durationSec % 60;
  document.getElementById('time-taken').textContent = `${minutes}:${String(seconds).padStart(2, '0')}`;
  
  document.getElementById('avg-score').textContent = `${averageScore}/10`;

  // Afficher les réponses détaillées
  displayAnswersDetail();

  // Gérer le bouton réessayer
  document.getElementById('retry-btn')?.addEventListener('click', () => {
    window.location.href = `quiz-play.html?id=${resultsState.quiz.id}`;
  });
}

// Animer le score
function animateScore(targetScore) {
  const scoreElement = document.getElementById('score-value');
  const progressCircle = document.getElementById('score-circle-progress');
  const circumference = 565.48;
  
  let currentScore = 0;
  const increment = targetScore / 50; // 50 frames d'animation
  const duration = 1500; // 1.5 secondes
  const frameTime = duration / 50;

  const interval = setInterval(() => {
    currentScore += increment;
    if (currentScore >= targetScore) {
      currentScore = targetScore;
      clearInterval(interval);
    }

    // Mettre à jour le texte
    scoreElement.textContent = currentScore.toFixed(1);

    // Mettre à jour le cercle de progression
    const progress = (currentScore / 10) * 100;
    const offset = circumference - (progress / 100) * circumference;
    progressCircle.style.strokeDashoffset = offset;

    // Changer la couleur selon le score
    if (currentScore >= 8) {
      progressCircle.style.stroke = '#10b981'; // Vert
    } else if (currentScore >= 6) {
      progressCircle.style.stroke = '#3b82f6'; // Bleu
    } else if (currentScore >= 4) {
      progressCircle.style.stroke = '#f59e0b'; // Orange
    } else {
      progressCircle.style.stroke = '#ef4444'; // Rouge
    }
  }, frameTime);
}

// Afficher les réponses détaillées
function displayAnswersDetail() {
  const container = document.getElementById('answers-detail');
  if (!container) return;

  // Grouper les réponses par question
  const questionMap = new Map();
  
  resultsState.answers.forEach(answer => {
    const questionId = answer.quiz_questions.id;
    if (!questionMap.has(questionId)) {
      questionMap.set(questionId, {
        question: answer.quiz_questions,
        userAnswers: []
      });
    }
    questionMap.get(questionId).userAnswers.push(answer);
  });

  // Afficher chaque question
  let questionNumber = 1;
  container.innerHTML = Array.from(questionMap.values()).map(item => {
    const isCorrect = item.userAnswers.every(a => a.is_correct);
    const statusIcon = isCorrect ? '✅' : '❌';
    const statusClass = isCorrect ? 'correct' : 'incorrect';
    const statusText = isCorrect ? 'Correct' : 'Incorrect';

    return `
      <div class="answer-detail-card answer-detail-card--${statusClass}">
        <div class="answer-detail-card__header">
          <div class="answer-detail-card__number">
            <span>Question ${questionNumber++}</span>
            <span class="answer-detail-card__status">${statusIcon} ${statusText}</span>
          </div>
        </div>
        
        <div class="answer-detail-card__content">
          <h3 class="answer-detail-card__question">${item.question.question}</h3>
          
          <div class="answer-detail-card__user-answer">
            <strong>Votre réponse :</strong>
            <ul>
              ${item.userAnswers.map(a => `
                <li class="${a.is_correct ? 'correct' : 'incorrect'}">
                  ${a.quiz_answers.label}
                  ${a.is_correct ? '✅' : '❌'}
                </li>
              `).join('')}
            </ul>
          </div>

          ${!isCorrect && item.userAnswers[0].quiz_answers ? `
            <div class="answer-detail-card__feedback">
              <strong>💡 Explication :</strong>
              <p>${item.question.explanation || item.userAnswers[0].quiz_answers.feedback || 'Pas d\'explication disponible.'}</p>
            </div>
          ` : ''}

          ${isCorrect && item.question.explanation ? `
            <div class="answer-detail-card__feedback answer-detail-card__feedback--success">
              <strong>💡 Explication :</strong>
              <p>${item.question.explanation}</p>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

// Afficher une erreur
function showError(message) {
  document.getElementById('quiz-loading').style.display = 'none';
  document.getElementById('quiz-error').style.display = 'flex';
  document.getElementById('error-message').textContent = message;
}

