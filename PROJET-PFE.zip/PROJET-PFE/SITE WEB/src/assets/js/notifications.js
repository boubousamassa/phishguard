// Système de notifications pour les achievements et level-up
export class NotificationSystem {
  constructor() {
    this.createNotificationContainer();
  }

  createNotificationContainer() {
    if (document.getElementById('notification-container')) return;
    
    const container = document.createElement('div');
    container.id = 'notification-container';
    container.style.cssText = `
      position: fixed;
      top: 80px;
      right: 20px;
      z-index: 10000;
      display: flex;
      flex-direction: column;
      gap: 10px;
      max-width: 350px;
    `;
    document.body.appendChild(container);
  }

  // Afficher une notification d'achievement débloqué
  showAchievementUnlocked(achievementName, icon, xpEarned) {
    const notification = document.createElement('div');
    notification.className = 'notification achievement-notification';
    notification.style.cssText = `
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 16px 20px;
      border-radius: 12px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.2);
      display: flex;
      align-items: center;
      gap: 12px;
      animation: slideInRight 0.5s ease-out, fadeOut 0.5s ease-in 4.5s;
      font-family: 'Inter', sans-serif;
    `;
    
    notification.innerHTML = `
      <span style="font-size: 32px;">${icon}</span>
      <div style="flex: 1;">
        <div style="font-size: 11px; text-transform: uppercase; opacity: 0.9; letter-spacing: 1px; margin-bottom: 2px;">Badge débloqué !</div>
        <div style="font-weight: 600; font-size: 15px; margin-bottom: 4px;">${achievementName}</div>
        <div style="font-size: 12px; opacity: 0.95;">+${xpEarned} XP</div>
      </div>
    `;
    
    this.showNotification(notification);
  }

  // Afficher une notification de level-up
  showLevelUp(newLevel, levelName) {
    const notification = document.createElement('div');
    notification.className = 'notification levelup-notification';
    notification.style.cssText = `
      background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
      color: white;
      padding: 16px 20px;
      border-radius: 12px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.2);
      display: flex;
      align-items: center;
      gap: 12px;
      animation: slideInRight 0.5s ease-out, fadeOut 0.5s ease-in 4.5s;
      font-family: 'Inter', sans-serif;
    `;
    
    notification.innerHTML = `
      <span style="font-size: 32px;">🎉</span>
      <div style="flex: 1;">
        <div style="font-size: 11px; text-transform: uppercase; opacity: 0.9; letter-spacing: 1px; margin-bottom: 2px;">Nouveau niveau !</div>
        <div style="font-weight: 600; font-size: 18px; margin-bottom: 4px;">Niveau ${newLevel}</div>
        <div style="font-size: 13px; opacity: 0.95;">${levelName}</div>
      </div>
    `;
    
    this.showNotification(notification);
  }

  // Afficher une notification de points gagnés
  showPointsEarned(points, reason) {
    const notification = document.createElement('div');
    notification.className = 'notification points-notification';
    notification.style.cssText = `
      background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
      color: white;
      padding: 12px 16px;
      border-radius: 10px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.15);
      display: flex;
      align-items: center;
      gap: 10px;
      animation: slideInRight 0.4s ease-out, fadeOut 0.4s ease-in 2.5s;
      font-family: 'Inter', sans-serif;
      font-size: 14px;
    `;
    
    notification.innerHTML = `
      <span style="font-size: 24px;">✨</span>
      <div style="flex: 1;">
        <div style="font-weight: 600; margin-bottom: 2px;">+${points} XP</div>
        <div style="font-size: 12px; opacity: 0.9;">${reason}</div>
      </div>
    `;
    
    this.showNotification(notification, 3000);
  }

  showNotification(notification, duration = 5000) {
    const container = document.getElementById('notification-container');
    if (!container) return;
    
    container.appendChild(notification);
    
    // Supprimer après le délai
    setTimeout(() => {
      notification.style.animation = 'fadeOut 0.3s ease-in';
      setTimeout(() => {
        notification.remove();
      }, 300);
    }, duration);
  }

  // Ajouter les animations CSS si elles n'existent pas
  static injectStyles() {
    if (document.getElementById('notification-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
      @keyframes slideInRight {
        from {
          transform: translateX(400px);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
      
      @keyframes fadeOut {
        from {
          opacity: 1;
        }
        to {
          opacity: 0;
        }
      }
      
      .notification {
        cursor: pointer;
        transition: transform 0.2s ease;
      }
      
      .notification:hover {
        transform: scale(1.02);
      }
    `;
    document.head.appendChild(style);
  }
}

// Initialiser les styles au chargement
NotificationSystem.injectStyles();

// Instance globale
export const notificationSystem = new NotificationSystem();

