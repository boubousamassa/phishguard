/**
 * Page catalogue des quiz - 4students-NovaX
 * Affiche tous les quiz disponibles avec filtres par niveau
 */
import { requireAuth } from './auth-guard.js';
import { authService } from '../../services/auth.js';
import { userService } from '../../services/userService.js';

document.addEventListener('DOMContentLoaded', async () => {
  // Vérification de l'authentification (redirection si non connecté)
  const user = await requireAuth();
  
  if (!user) {
    // Redirection en cours, arrêter l'exécution
    return;
  }
  
  // Affichage du nom d'utilisateur dans le header
  updateHeaderForAuthenticatedUser(user);

  // Chargement du catalogue et des statistiques
  await loadQuizData(user?.id);

  // Système de filtres par niveau
  const filters = document.querySelectorAll('.quiz-hero__filters .filter');
  
  // Initialisation des filtres (appelée après chargement des quiz)
  function initializeFilters() {
    const cards = document.querySelectorAll('.quiz-card');
    
    filters.forEach(filter => {
      filter.addEventListener('click', () => {
        const target = filter.dataset.filter ?? 'all';
        
        // Mise à jour visuelle des filtres actifs
        filters.forEach(btn => btn.classList.toggle('is-active', btn === filter));

        // Filtrage avec animations
        cards.forEach(card => {
          const level = card.dataset.level ?? 'all';
          const shouldShow = target === 'all' || level === target;
          
          if (shouldShow) {
            // Animation d'apparition
            card.style.display = 'grid';
            card.offsetHeight; // Force reflow
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
          } else {
            // Animation de disparition
            card.style.opacity = '0';
            card.style.transform = 'scale(0.95)';
            // Masquage complet après transition
            setTimeout(() => {
              if (card.style.opacity === '0') {
                card.style.display = 'none';
              }
            }, 300);
          }
        });
      });
    });
  }
  
  // Appel initial des filtres
  initializeFilters();
});

// ==================================
// Header pour utilisateur connecté
// ==================================
function updateHeaderForAuthenticatedUser(user) {
  const headerCta = document.querySelector('.site-header__cta');
  if (headerCta) {
    const userName = user.user_metadata?.name || user.email?.split('@')[0] || 'Utilisateur';
    headerCta.innerHTML = `
      <span class="session-chip">
        <span class="session-chip__status" aria-hidden="true"></span>
        Bonjour, ${userName} 👋
      </span>
      <a class="btn btn--ghost btn--small" href="#" id="logout-btn">Déconnexion</a>
    `;

    // Bouton de déconnexion
    document.getElementById('logout-btn')?.addEventListener('click', async (e) => {
      e.preventDefault();
      await authService.signOut();
      window.location.href = '../../public/login.html';
    });
  }
}

// ==================================
// Chargement des quiz et statistiques
// ==================================
async function loadQuizData(userId) {
  try {
    // Récupération du catalogue complet
    const quizResult = await userService.getAllQuizzes();
    
    if (quizResult.success && quizResult.data) {
      updateQuizCatalog(quizResult.data);
    } else {
      // Message si catalogue vide
      const catalogGrid = document.querySelector('.quiz-catalog__grid');
      if (catalogGrid) {
        catalogGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; padding: 40px 20px; color: var(--text-muted);">Aucun quiz disponible pour le moment.</p>';
      }
    }

    // Chargement des statistiques utilisateur (si connecté)
    if (userId) {
      const userQuizSessions = await userService.getUserQuizSessions(userId);
      const levelResult = await userService.getUserLevel(userId);
      
      if (userQuizSessions.success && levelResult.success) {
        updateProgressSummary(userQuizSessions.data, levelResult.data);
      }
    }
  } catch (error) {
    console.error('Erreur lors du chargement des quiz:', error);
    const catalogGrid = document.querySelector('.quiz-catalog__grid');
    if (catalogGrid) {
      catalogGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; padding: 40px 20px; color: var(--color-danger);">Erreur lors du chargement des quiz. Veuillez rafraîchir la page.</p>';
    }
  }
}

// ==================================
// Génération du catalogue HTML
// ==================================
function updateQuizCatalog(quizzes) {
  const catalogGrid = document.querySelector('.quiz-catalog__grid');
  if (!catalogGrid) return;
  
  if (!quizzes || quizzes.length === 0) {
    catalogGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; padding: 40px 20px; color: var(--text-muted);">Aucun quiz disponible pour le moment.</p>';
    return;
  }

  catalogGrid.innerHTML = quizzes.map(quiz => {
    const levelLabel = getLevelLabel(quiz.level);
    return `
      <article class="quiz-card" data-level="${quiz.level || 'beginner'}">
        <span class="quiz-card__level">${levelLabel}</span>
        <h3>${quiz.title}</h3>
        <p>${quiz.description || 'Testez vos connaissances sur ce sujet.'}</p>
        <footer>
          <span class="quiz-card__score">Questions : ${quiz.total_questions || 10}</span>
          <button class="btn btn--secondary btn--small" type="button" 
                  data-action="start-quiz" data-quiz-id="${quiz.id}">
            Jouer
          </button>
        </footer>
      </article>
    `;
  }).join('');

  // Attachement des événements sur les boutons "Jouer"
  const startButtons = catalogGrid.querySelectorAll('[data-action="start-quiz"]');
  startButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const quizId = btn.dataset.quizId;
      // Redirection vers la page de jeu
      window.location.href = `../pages/quiz-play.html?id=${quizId}`;
    });
  });
  
  // Réinitialisation des filtres pour le nouveau contenu
  reinitializeFiltersAfterLoad();
}

// Helper : réinitialisation des filtres après chargement dynamique
function reinitializeFiltersAfterLoad() {
  const filters = document.querySelectorAll('.quiz-hero__filters .filter');
  const cards = document.querySelectorAll('.quiz-card');
  
  // Supprimer les anciens event listeners en clonant les éléments
  filters.forEach(filter => {
    const newFilter = filter.cloneNode(true);
    filter.parentNode.replaceChild(newFilter, filter);
  });
  
  // Réattachement des événements
  const newFilters = document.querySelectorAll('.quiz-hero__filters .filter');
  newFilters.forEach(filter => {
    filter.addEventListener('click', () => {
      const target = filter.dataset.filter ?? 'all';
      
      // Mise à jour visuelle
      newFilters.forEach(btn => btn.classList.toggle('is-active', btn === filter));

      // Filtrage avec animation
      const allCards = document.querySelectorAll('.quiz-card');
      allCards.forEach(card => {
        const level = card.dataset.level ?? 'all';
        const shouldShow = target === 'all' || level === target;
        
        if (shouldShow) {
          // Animation d'apparition
          card.style.display = 'grid';
          card.offsetHeight; // Force reflow
          card.style.opacity = '1';
          card.style.transform = 'scale(1)';
        } else {
          // Animation de disparition
          card.style.opacity = '0';
          card.style.transform = 'scale(0.95)';
          // Masquage complet après transition
          setTimeout(() => {
            if (card.style.opacity === '0') {
              card.style.display = 'none';
            }
          }, 300);
        }
      });
    });
  });
}

// ==================================
// Résumé de progression utilisateur
// ==================================
function updateProgressSummary(sessions, levelData) {
  const progressSummary = document.querySelector('.progress-summary');
  if (!progressSummary) return;

  const completedQuizzes = sessions.length;
  const avgScore = sessions.length > 0 
    ? (sessions.reduce((sum, s) => sum + parseFloat(s.score || 0), 0) / sessions.length).toFixed(1)
    : 0;

  // Calcul de la progression (100 XP = 1 niveau)
  const currentLevelXP = levelData?.xp % 100 || 0;
  const progressPercent = currentLevelXP;
  const nextLevel = (levelData?.level || 1) + 1;

  progressSummary.innerHTML = `
    <span class="progress-summary__label">Progression globale</span>
    <strong>${completedQuizzes} quiz</strong>
    <div class="progress-summary__bar" role="progressbar" aria-valuemin="0" 
         aria-valuemax="100" aria-valuenow="${progressPercent}">
      <div style="width: ${progressPercent}%"></div>
    </div>
    <span class="progress-summary__note">${completedQuizzes > 0 ? `Score moyen : ${avgScore}/10` : `Commencez un quiz pour débuter votre progression !`}</span>
  `;

  // Statistiques par niveau de difficulté
  const quizStatus = document.querySelector('.quiz-status');
  if (quizStatus) {
    const beginnerCount = sessions.filter(s => s.quizzes?.level === 'beginner').length;
    const intermediateCount = sessions.filter(s => s.quizzes?.level === 'intermediate').length;
    const advancedCount = sessions.filter(s => s.quizzes?.level === 'advanced').length;

    quizStatus.innerHTML = `
      <li><span>Débutant</span><strong>${beginnerCount} complété${beginnerCount > 1 ? 's' : ''}</strong></li>
      <li><span>Intermédiaire</span><strong>${intermediateCount} complété${intermediateCount > 1 ? 's' : ''}</strong></li>
      <li><span>Avancé</span><strong>${advancedCount} complété${advancedCount > 1 ? 's' : ''}</strong></li>
    `;
  }
}

// Helper : traduction des niveaux
function getLevelLabel(level) {
  const labels = {
    'beginner': 'Débutant',
    'intermediate': 'Intermédiaire',
    'advanced': 'Avancé'
  };
  return labels[level] || 'Débutant';
}
