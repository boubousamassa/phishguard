/**
 * Page de jeu de quiz - 4students-NovaX
 * Gère le déroulement d'un quiz : questions, réponses, feedback et timer
 */
import { requireAuth } from './auth-guard.js';
import { authService } from '../../services/auth.js';
import { quizService } from '../../services/quizService.js';

// État global du quiz en cours
const quizState = {
  user: null,
  quizId: null,
  quiz: null,
  questions: [],
  currentQuestionIndex: 0,
  sessionId: null,
  userAnswers: {},
  startTime: null,
  timerInterval: null,
  elapsedSeconds: 0
};

// Initialisation
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Vérifier l'authentification (redirection si non connecté)
    quizState.user = await requireAuth();
    
    if (!quizState.user) {
      // Redirection en cours, arrêter l'exécution
      return;
    }

    // Récupérer l'ID du quiz depuis l'URL
    const urlParams = new URLSearchParams(window.location.search);
    quizState.quizId = urlParams.get('id');

    if (!quizState.quizId) {
      showError('Aucun quiz sélectionné.');
      return;
    }

    // Charger le quiz
    await loadQuiz();
    
    // Initialiser les gestionnaires de sortie
    initializeExitHandlers();
  } catch (error) {
    console.error('Erreur lors de l\'initialisation:', error);
    showError('Une erreur est survenue lors du chargement.');
  }
});

// Charger le quiz et ses questions
async function loadQuiz() {
  try {
    // Récupérer le quiz
    const quizResult = await quizService.getQuizById(quizState.quizId);
    if (!quizResult.success) {
      throw new Error(quizResult.error);
    }
    quizState.quiz = quizResult.data;

    // Récupérer les questions
    const questionsResult = await quizService.getQuizQuestions(quizState.quizId);
    if (!questionsResult.success) {
      throw new Error(questionsResult.error);
    }
    quizState.questions = questionsResult.data;

    if (quizState.questions.length === 0) {
      throw new Error('Ce quiz ne contient aucune question.');
    }

    // Charger les réponses pour chaque question
    for (let question of quizState.questions) {
      const answersResult = await quizService.getQuestionAnswers(question.id);
      if (answersResult.success) {
        question.answers = answersResult.data;
      }
    }

    // Créer une session
    const sessionResult = await quizService.createQuizSession(quizState.user.id, quizState.quizId);
    if (!sessionResult.success) {
      throw new Error(sessionResult.error);
    }
    quizState.sessionId = sessionResult.data.id;

    // Initialiser le quiz
    initializeQuiz();
  } catch (error) {
    console.error('Erreur lors du chargement du quiz:', error);
    showError(error.message);
  }
}

// Initialiser l'interface du quiz
function initializeQuiz() {
  // Masquer l'écran de chargement
  document.getElementById('quiz-loading').style.display = 'none';
  document.getElementById('quiz-content').style.display = 'block';

  // Mettre à jour le titre
  document.getElementById('quiz-title').textContent = quizState.quiz.title;

  // Démarrer le timer
  quizState.startTime = Date.now();
  startTimer();

  // Charger la première question
  loadQuestion(0);

  // Initialiser les event listeners
  initializeEventListeners();
}

// Initialiser les event listeners
function initializeEventListeners() {
  // Bouton précédent
  document.getElementById('prev-question-btn')?.addEventListener('click', () => {
    if (quizState.currentQuestionIndex > 0) {
      loadQuestion(quizState.currentQuestionIndex - 1);
    }
  });

  // Bouton suivant (après feedback)
  document.getElementById('next-question-btn')?.addEventListener('click', () => {
    if (quizState.currentQuestionIndex < quizState.questions.length - 1) {
      loadQuestion(quizState.currentQuestionIndex + 1);
    } else {
      // Terminer le quiz
      completeQuiz();
    }
  });

  // Bouton valider réponse
  document.getElementById('submit-answer-btn')?.addEventListener('click', submitAnswer);

  // Confirmer la sortie
  window.addEventListener('beforeunload', (e) => {
    if (quizState.sessionId && quizState.currentQuestionIndex < quizState.questions.length) {
      e.preventDefault();
      e.returnValue = '';
    }
  });
}

// Charger une question
function loadQuestion(index) {
  quizState.currentQuestionIndex = index;
  const question = quizState.questions[index];

  // Masquer le feedback
  document.getElementById('quiz-feedback').style.display = 'none';
  document.getElementById('quiz-navigation').style.display = 'flex';

  // Mettre à jour la progression
  const progressPercent = ((index + 1) / quizState.questions.length) * 100;
  document.getElementById('progress-bar').style.width = progressPercent + '%';
  document.getElementById('quiz-progress').textContent = `Question ${index + 1}/${quizState.questions.length}`;
  document.getElementById('question-number').textContent = `Question ${index + 1}`;

  // Mettre à jour le type de question
  const questionType = question.question_type === 'multiple' ? 'Choix multiple' : 'Choix unique';
  document.getElementById('question-type').textContent = questionType;

  // Afficher la question
  document.getElementById('question-text').textContent = question.question;

  // Afficher les réponses
  displayAnswers(question);

  // Gérer le bouton précédent
  const prevBtn = document.getElementById('prev-question-btn');
  if (prevBtn) {
    prevBtn.disabled = index === 0;
  }

  // Réinitialiser le bouton de soumission
  const submitBtn = document.getElementById('submit-answer-btn');
  if (submitBtn) {
    submitBtn.disabled = true;
  }
}

// Afficher les réponses
function displayAnswers(question) {
  const answersContainer = document.getElementById('quiz-answers');
  if (!answersContainer) return;

  const isMultiple = question.question_type === 'multiple';
  const inputType = isMultiple ? 'checkbox' : 'radio';
  const savedAnswer = quizState.userAnswers[question.id];

  answersContainer.innerHTML = question.answers.map((answer, index) => {
    const isChecked = savedAnswer && savedAnswer.includes(answer.id) ? 'checked' : '';
    const letter = String.fromCharCode(65 + index); // A, B, C, D...

    return `
      <label class="quiz-answer" data-answer-id="${answer.id}">
        <input 
          type="${inputType}" 
          name="answer-${question.id}" 
          value="${answer.id}"
          ${isChecked}
          onchange="window.handleAnswerChange()"
        />
        <span class="quiz-answer__letter">${letter}</span>
        <span class="quiz-answer__text">${answer.label}</span>
        <span class="quiz-answer__check">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16.6666 5L7.49998 14.1667L3.33331 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </span>
      </label>
    `;
  }).join('');

  // Vérifier si une réponse est déjà sauvegardée
  if (savedAnswer) {
    document.getElementById('submit-answer-btn').disabled = false;
  }
}

// Gérer le changement de réponse (fonction globale accessible depuis le HTML)
window.handleAnswerChange = function() {
  const submitBtn = document.getElementById('submit-answer-btn');
  const question = quizState.questions[quizState.currentQuestionIndex];
  const selectedInputs = document.querySelectorAll(`input[name="answer-${question.id}"]:checked`);
  
  if (submitBtn) {
    submitBtn.disabled = selectedInputs.length === 0;
  }
};

// Soumettre une réponse
async function submitAnswer() {
  const question = quizState.questions[quizState.currentQuestionIndex];
  const selectedInputs = document.querySelectorAll(`input[name="answer-${question.id}"]:checked`);
  
  if (selectedInputs.length === 0) {
    return;
  }

  const selectedAnswerIds = Array.from(selectedInputs).map(input => parseInt(input.value));
  
  // Sauvegarder la réponse dans l'état local
  quizState.userAnswers[question.id] = selectedAnswerIds;

  // Désactiver les inputs
  selectedInputs.forEach(input => input.disabled = true);
  document.querySelectorAll(`input[name="answer-${question.id}"]`).forEach(input => {
    input.disabled = true;
  });

  // Masquer la navigation
  document.getElementById('quiz-navigation').style.display = 'none';

  // Sauvegarder les réponses dans la base de données
  try {
    let allCorrect = true;
    let feedbackMessages = [];

    for (const answerId of selectedAnswerIds) {
      const result = await quizService.saveUserAnswer(quizState.sessionId, question.id, answerId);
      if (result.success) {
        if (!result.isCorrect) {
          allCorrect = false;
        }
        // Récupérer le feedback pour cette réponse
        const answerData = question.answers.find(a => a.id === answerId);
        if (answerData && answerData.feedback) {
          feedbackMessages.push(answerData.feedback);
        }
      }
    }

    // Marquer visuellement les réponses
    markAnswers(question, selectedAnswerIds);

    // Afficher le feedback
    showFeedback(allCorrect, question.explanation, feedbackMessages);
  } catch (error) {
    console.error('Erreur lors de la soumission de la réponse:', error);
    alert('Une erreur est survenue lors de la sauvegarde de votre réponse.');
  }
}

// Marquer les réponses (correct/incorrect)
function markAnswers(question, selectedAnswerIds) {
  const answerElements = document.querySelectorAll('.quiz-answer');
  
  answerElements.forEach(element => {
    const answerId = parseInt(element.dataset.answerId);
    const answer = question.answers.find(a => a.id === answerId);
    
    if (selectedAnswerIds.includes(answerId)) {
      if (answer.is_correct) {
        element.classList.add('quiz-answer--correct');
      } else {
        element.classList.add('quiz-answer--incorrect');
      }
    } else if (answer.is_correct) {
      element.classList.add('quiz-answer--correct-not-selected');
    }
  });
}

// Afficher le feedback
function showFeedback(isCorrect, explanation, feedbackMessages) {
  const feedbackElement = document.getElementById('quiz-feedback');
  const feedbackIcon = document.getElementById('feedback-icon');
  const feedbackTitle = document.getElementById('feedback-title');
  const feedbackMessage = document.getElementById('feedback-message');
  const nextBtn = document.getElementById('next-question-btn');

  if (isCorrect) {
    feedbackIcon.textContent = '✅';
    feedbackTitle.textContent = 'Correct !';
    feedbackElement.classList.add('quiz-feedback--correct');
    feedbackElement.classList.remove('quiz-feedback--incorrect');
  } else {
    feedbackIcon.textContent = '❌';
    feedbackTitle.textContent = 'Incorrect';
    feedbackElement.classList.add('quiz-feedback--incorrect');
    feedbackElement.classList.remove('quiz-feedback--correct');
  }

  // Construire le message de feedback
  let message = explanation || 'Passez à la question suivante.';
  if (feedbackMessages.length > 0) {
    message = feedbackMessages.join(' ') + ' ' + message;
  }
  feedbackMessage.textContent = message;

  // Mettre à jour le texte du bouton suivant
  if (quizState.currentQuestionIndex === quizState.questions.length - 1) {
    nextBtn.textContent = 'Voir les résultats';
  } else {
    nextBtn.textContent = 'Question suivante';
  }

  feedbackElement.style.display = 'block';
}

// Terminer le quiz
async function completeQuiz() {
  try {
    // Arrêter le timer
    stopTimer();

    // Calculer le score
    const scoreResult = await quizService.calculateSessionScore(quizState.sessionId);
    if (!scoreResult.success) {
      throw new Error(scoreResult.error);
    }

    // Mettre à jour la session
    await quizService.completeQuizSession(
      quizState.sessionId,
      scoreResult.score,
      quizState.elapsedSeconds
    );

    // Rediriger vers la page de résultats
    window.location.href = `quiz-results.html?session=${quizState.sessionId}`;
  } catch (error) {
    console.error('Erreur lors de la complétion du quiz:', error);
    alert('Une erreur est survenue. Veuillez réessayer.');
  }
}

// Gérer le timer
function startTimer() {
  quizState.timerInterval = setInterval(() => {
    quizState.elapsedSeconds++;
    updateTimerDisplay();
  }, 1000);
}

function stopTimer() {
  if (quizState.timerInterval) {
    clearInterval(quizState.timerInterval);
    quizState.timerInterval = null;
  }
}

function updateTimerDisplay() {
  const minutes = Math.floor(quizState.elapsedSeconds / 60);
  const seconds = quizState.elapsedSeconds % 60;
  const display = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  
  const timerElement = document.getElementById('timer-display');
  if (timerElement) {
    timerElement.textContent = display;
  }
}

// Afficher une erreur
function showError(message) {
  document.getElementById('quiz-loading').style.display = 'none';
  document.getElementById('quiz-error').style.display = 'flex';
  document.getElementById('error-message').textContent = message;
}

// Initialiser les gestionnaires de sortie du quiz
function initializeExitHandlers() {
  const exitBtn = document.getElementById('exit-quiz-btn');
  const exitModal = document.getElementById('exit-modal');
  const cancelBtn = document.getElementById('cancel-exit-btn');
  const confirmBtn = document.getElementById('confirm-exit-btn');
  const modalOverlay = exitModal?.querySelector('.modal__overlay');

  // Ouvrir la modal de confirmation
  if (exitBtn) {
    exitBtn.addEventListener('click', () => {
      if (exitModal) {
        exitModal.style.display = 'flex';
      }
    });
  }

  // Fermer la modal (annuler)
  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      if (exitModal) {
        exitModal.style.display = 'none';
      }
    });
  }

  // Fermer en cliquant sur l'overlay
  if (modalOverlay) {
    modalOverlay.addEventListener('click', () => {
      if (exitModal) {
        exitModal.style.display = 'none';
      }
    });
  }

  // Confirmer la sortie
  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      // Arrêter le timer
      if (quizState.timerInterval) {
        clearInterval(quizState.timerInterval);
      }
      // Rediriger vers la page des quiz
      window.location.href = '../components/quiz.html';
    });
  }

  // Fermer avec la touche Échap
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && exitModal?.style.display === 'flex') {
      exitModal.style.display = 'none';
    }
  });
}

