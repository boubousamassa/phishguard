/**
 * Script principal - Navigation mobile
 * Gère le menu burger et le scroll smooth
 */
document.addEventListener('DOMContentLoaded', () => {
  const burger = document.querySelector('.site-header__burger');
  const nav = document.querySelector('.primary-nav');
  const body = document.body;

  const setNavState = (isOpen) => {
    if (!nav || !burger) return;
    nav.classList.toggle('is-open', isOpen);
    burger.classList.toggle('is-open', isOpen);
    burger.setAttribute('aria-expanded', String(isOpen));
    body.style.overflow = isOpen ? 'hidden' : '';
  };

  burger?.addEventListener('click', () => {
    const isOpen = !nav?.classList.contains('is-open');
    setNavState(isOpen);
  });

  nav?.addEventListener('click', (event) => {
    if (event.target instanceof HTMLElement && event.target.matches('a')) {
      setNavState(false);
    }
  });

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (event) => {
      const targetId = anchor.getAttribute('href');
      if (targetId && targetId.length > 1) {
        const target = document.querySelector(targetId);
        if (target) {
          event.preventDefault();
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
          setNavState(false);
        }
      }
    });
  });
});
