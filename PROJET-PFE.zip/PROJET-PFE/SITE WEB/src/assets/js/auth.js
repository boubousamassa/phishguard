/**
 * Page d'authentification (login/register)
 * Gère les onglets, formulaires et la logique d'inscription/connexion
 */
import { authService } from '../../services/auth.js';

const tabs = document.querySelectorAll('.auth-card__tab');
const forms = document.querySelectorAll('.auth-form');

const activateTab = (targetName) => {
  tabs.forEach((tab) => {
    const isTarget = tab.dataset.target === targetName;
    tab.classList.toggle('is-active', isTarget);
    tab.setAttribute('aria-selected', String(isTarget));
  });

  forms.forEach((form) => {
    const isTarget = form.dataset.form === targetName;
    form.classList.toggle('is-active', isTarget);
    form.toggleAttribute('hidden', !isTarget);
    if (isTarget) {
      const firstInput = form.querySelector('input');
      firstInput?.focus({ preventScroll: true });
    }
  });
};

tabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    activateTab(tab.dataset.target);
    if (history.replaceState) {
      history.replaceState(null, '', `#${tab.dataset.target}`);
    }
  });
});

const hash = window.location.hash.replace('#', '');
if (hash && ['login', 'register'].includes(hash)) {
  activateTab(hash);
} else {
  activateTab('login');
}

// ==================================
// Formulaire de connexion
// ==================================
const loginForm = document.querySelector('[data-form="login"]');
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = loginForm.querySelector('#login-email').value;
    const password = loginForm.querySelector('#login-password').value;
    const submitBtn = loginForm.querySelector('button[type="submit"]');
    
    // Désactivation du bouton pour éviter les doubles soumissions
    submitBtn.disabled = true;
    submitBtn.textContent = 'Connexion...';

    try {
      const result = await authService.signIn(email, password);
      
      if (result.success) {
        // Vérifier s'il y a une URL de redirection dans les paramètres
        const urlParams = new URLSearchParams(window.location.search);
        const redirectUrl = urlParams.get('redirect');
        
        if (redirectUrl && redirectUrl.startsWith(window.location.origin)) {
          // Redirection vers la page demandée
          window.location.href = redirectUrl;
        } else {
          // Redirection par défaut vers le dashboard
          window.location.href = '../src/pages/dashboard.html';
        }
      } else {
        // Affichage d'un message d'erreur
        alert(`Erreur de connexion: ${result.error}`);
        submitBtn.disabled = false;
        submitBtn.textContent = 'Se connecter';
      }
    } catch (error) {
      alert(`Erreur de connexion: ${error.message}`);
      submitBtn.disabled = false;
      submitBtn.textContent = 'Se connecter';
    }
  });
}

// ==================================
// Formulaire d'inscription
// ==================================
const registerForm = document.querySelector('[data-form="register"]');
if (registerForm) {
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = registerForm.querySelector('#register-name').value;
    const email = registerForm.querySelector('#register-email').value;
    const password = registerForm.querySelector('#register-password').value;
    const confirm = registerForm.querySelector('#register-confirm').value;
    const submitBtn = registerForm.querySelector('button[type="submit"]');

    // Validation: les mots de passe doivent correspondre
    if (password !== confirm) {
      alert('Les mots de passe ne correspondent pas');
      return;
    }

    // Validation: longueur minimale du mot de passe
    if (password.length < 6) {
      alert('Le mot de passe doit contenir au moins 6 caractères');
      return;
    }

    // Désactivation du bouton pendant la requête
    submitBtn.disabled = true;
    submitBtn.textContent = 'Création...';

    try {
      const result = await authService.signUp(email, password, name);
      
      if (result.success) {
        if (result.isAutoConfirmed) {
          alert('Inscription réussie ! Vous êtes maintenant connecté.');
          window.location.href = '../src/pages/dashboard.html';
        } else {
          alert('Inscription réussie ! Un email de confirmation a été envoyé à votre adresse. Veuillez vérifier votre boîte de réception (et vos spams) et cliquer sur le lien pour confirmer votre compte.');
          activateTab('login');
          
          // Pré-remplir l'email pour faciliter la connexion
          if (loginForm) {
            loginForm.querySelector('#login-email').value = email;
          }
        }
      } else {
        alert(`Erreur lors de l'inscription: ${result.error}`);
      }
    } catch (error) {
      alert(`Erreur lors de l'inscription: ${error.message}`);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Créer mon compte';
    }
  });
}

// ==================================
// Bouton "Continuer en invité"
// ==================================
const guestButton = document.querySelector('.btn--ghost[type="button"]');
if (guestButton && guestButton.textContent.includes('invité')) {
  guestButton.addEventListener('click', () => {
    // Redirection vers la page de connexion car l'authentification est requise
    alert('Veuillez vous connecter pour accéder au site.');
    activateTab('login');
  });
}

// ==================================
// Réinitialisation du mot de passe
// ==================================
const forgotPasswordLink = document.querySelector('.field__link');
if (forgotPasswordLink) {
  forgotPasswordLink.addEventListener('click', async (e) => {
    e.preventDefault();
    const email = loginForm?.querySelector('#login-email').value;
    
    if (!email) {
      const emailInput = prompt('Veuillez entrer votre adresse email:');
      if (emailInput) {
        const result = await authService.resetPassword(emailInput);
        if (result.success) {
          alert('Un email de réinitialisation a été envoyé à votre adresse.');
        } else {
          alert(`Erreur: ${result.error}`);
        }
      }
    } else {
      const result = await authService.resetPassword(email);
      if (result.success) {
        alert('Un email de réinitialisation a été envoyé à votre adresse.');
      } else {
        alert(`Erreur: ${result.error}`);
      }
    }
  });
}
