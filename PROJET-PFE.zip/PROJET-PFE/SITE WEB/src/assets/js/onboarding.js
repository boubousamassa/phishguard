/**
 * Système d'onboarding interactif - 4students-NovaX
 * Gère le tutoriel animé au premier login et la quête de bienvenue
 */
import { authService } from '../../services/auth.js';
import { userService } from '../../services/userService.js';
import { getSupabaseClient } from '../../config/supabase.js';

class OnboardingSystem {
  constructor() {
    this.currentStep = 0;
    this.steps = [];
    this.isActive = false;
  }

  /**
   * Vérifie si l'utilisateur a déjà complété l'onboarding
   */
  async checkOnboardingStatus(userId) {
    try {
      // Vérifier dans les métadonnées utilisateur ou une table dédiée
      const user = await authService.getCurrentUser();
      if (!user) return false;
      
      // Vérifier si l'onboarding a été complété
      const onboardingCompleted = user.user_metadata?.onboarding_completed || false;
      return !onboardingCompleted;
    } catch (error) {
      console.error('Erreur lors de la vérification de l\'onboarding:', error);
      return false;
    }
  }

  /**
   * Démarre l'onboarding interactif
   */
  async startOnboarding() {
    if (this.isActive) return;
    
    this.isActive = true;
    this.currentStep = 0;
    
    // Créer l'overlay d'onboarding
    this.createOnboardingOverlay();
    
    // Démarrer avec la première étape
    await this.showStep(0);
  }

  /**
   * Crée l'overlay et le conteneur pour l'onboarding
   */
  createOnboardingOverlay() {
    // Supprimer l'overlay existant s'il y en a un
    const existing = document.getElementById('onboarding-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'onboarding-overlay';
    overlay.className = 'onboarding-overlay';
    
    const container = document.createElement('div');
    container.className = 'onboarding-container';
    
    const content = document.createElement('div');
    content.className = 'onboarding-content';
    content.id = 'onboarding-content';
    
    const navigation = document.createElement('div');
    navigation.className = 'onboarding-navigation';
    
    const prevBtn = document.createElement('button');
    prevBtn.className = 'btn btn--ghost onboarding-btn-prev';
    prevBtn.textContent = 'Précédent';
    prevBtn.style.display = 'none';
    
    const nextBtn = document.createElement('button');
    nextBtn.className = 'btn btn--primary onboarding-btn-next';
    nextBtn.textContent = 'Suivant';
    
    const skipBtn = document.createElement('button');
    skipBtn.className = 'onboarding-btn-skip';
    skipBtn.textContent = 'Passer';
    
    navigation.appendChild(prevBtn);
    navigation.appendChild(nextBtn);
    navigation.appendChild(skipBtn);
    
    container.appendChild(content);
    container.appendChild(navigation);
    overlay.appendChild(container);
    
    document.body.appendChild(overlay);
    
    // Event listeners
    prevBtn.addEventListener('click', () => this.previousStep());
    nextBtn.addEventListener('click', () => this.nextStep());
    skipBtn.addEventListener('click', () => this.skipOnboarding());
    
    // Animation d'entrée
    setTimeout(() => {
      overlay.classList.add('is-visible');
    }, 100);
  }

  /**
   * Définit les étapes de l'onboarding
   */
  setSteps(steps) {
    this.steps = steps;
  }

  /**
   * Affiche une étape spécifique
   */
  async showStep(stepIndex) {
    if (stepIndex < 0 || stepIndex >= this.steps.length) {
      await this.completeOnboarding();
      return;
    }

    this.currentStep = stepIndex;
    const step = this.steps[stepIndex];
    const content = document.getElementById('onboarding-content');
    const prevBtn = document.querySelector('.onboarding-btn-prev');
    const nextBtn = document.querySelector('.onboarding-btn-next');
    
    if (!content) return;

    // Animation de sortie
    content.style.opacity = '0';
    content.style.transform = 'translateY(20px)';
    
    await new Promise(resolve => setTimeout(resolve, 200));
    
    // Mise à jour du contenu
    content.innerHTML = `
      <div class="onboarding-icon">${step.icon || '🎓'}</div>
      <h2 class="onboarding-title">${step.title}</h2>
      <p class="onboarding-description">${step.description}</p>
      ${step.content || ''}
    `;
    
    // Mise à jour des boutons
    prevBtn.style.display = stepIndex === 0 ? 'none' : 'inline-flex';
    nextBtn.textContent = stepIndex === this.steps.length - 1 ? 'Commencer !' : 'Suivant';
    
    // Animation d'entrée
    setTimeout(() => {
      content.style.opacity = '1';
      content.style.transform = 'translateY(0)';
    }, 50);
    
    // Highlight d'éléments si nécessaire
    if (step.highlight) {
      this.highlightElement(step.highlight);
    }
  }

  /**
   * Étape suivante
   */
  async nextStep() {
    if (this.currentStep < this.steps.length - 1) {
      await this.showStep(this.currentStep + 1);
    } else {
      await this.completeOnboarding();
    }
  }

  /**
   * Étape précédente
   */
  async previousStep() {
    if (this.currentStep > 0) {
      await this.showStep(this.currentStep - 1);
    }
  }

  /**
   * Met en évidence un élément de la page
   */
  highlightElement(selector) {
    const element = document.querySelector(selector);
    if (element) {
      element.classList.add('onboarding-highlight');
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  /**
   * Complète l'onboarding et attribue les récompenses
   */
  async completeOnboarding() {
    try {
      const user = await authService.getCurrentUser();
      if (!user) return;

      // Marquer l'onboarding comme complété
      const supabase = await getSupabaseClient();
      await supabase.auth.updateUser({
        data: { onboarding_completed: true }
      });

      // Attribuer les récompenses de bienvenue
      await this.giveWelcomeRewards(user.id);

      // Animation de fermeture
      const overlay = document.getElementById('onboarding-overlay');
      if (overlay) {
        overlay.classList.remove('is-visible');
        setTimeout(() => {
          overlay.remove();
        }, 300);
      }

      this.isActive = false;
      
      // Afficher un message de succès
      this.showCompletionMessage();
    } catch (error) {
      console.error('Erreur lors de la complétion de l\'onboarding:', error);
    }
  }

  /**
   * Attribue les récompenses de bienvenue
   */
  async giveWelcomeRewards(userId) {
    try {
      // Donner 50 XP de bienvenue
      const levelResult = await userService.getUserLevel(userId);
      const currentXP = levelResult.success && levelResult.data ? levelResult.data.xp : 0;
      
      await userService.upsertUserLevel(userId, {
        level: 1,
        xp: currentXP + 50,
        total_points: 50
      });

      // Débloquer le badge de bienvenue si disponible
      // (nécessite que le badge existe dans la base de données)
    } catch (error) {
      console.error('Erreur lors de l\'attribution des récompenses:', error);
    }
  }

  /**
   * Affiche un message de complétion
   */
  showCompletionMessage() {
    const message = document.createElement('div');
    message.className = 'onboarding-completion-message';
    message.innerHTML = `
      <div class="completion-icon">🎉</div>
      <h3>Bienvenue dans 4Students !</h3>
      <p>Vous avez gagné <strong>50 XP</strong> de bienvenue !</p>
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
      message.classList.add('is-visible');
    }, 100);
    
    setTimeout(() => {
      message.classList.remove('is-visible');
      setTimeout(() => message.remove(), 300);
    }, 3000);
  }

  /**
   * Passe l'onboarding
   */
  async skipOnboarding() {
    await this.completeOnboarding();
  }
}

export const onboardingSystem = new OnboardingSystem();

