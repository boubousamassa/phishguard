/**
 * Module de protection d'authentification - 4students-NovaX
 * Vérifie que l'utilisateur est connecté avant d'accéder aux pages protégées
 * Redirige vers la page de connexion si l'utilisateur n'est pas authentifié
 */
import { authService } from '../../services/auth.js';

/**
 * Vérifie l'authentification et redirige si nécessaire
 * @param {string} redirectPath - Chemin de redirection vers login (optionnel)
 * @returns {Promise<Object|null>} L'utilisateur connecté ou null si redirection
 */
export async function requireAuth(redirectPath = null) {
  try {
    const user = await authService.getCurrentUser();
    
    if (!user) {
      // Construction du chemin de redirection
      let loginPath = redirectPath;
      
      if (!loginPath) {
        // Détermination automatique du chemin selon la structure
        const currentPath = window.location.pathname;
        if (currentPath.includes('/src/pages/') || currentPath.includes('/src/components/')) {
          loginPath = '../../public/login.html';
        } else if (currentPath.includes('/public/')) {
          loginPath = './login.html';
        } else {
          loginPath = './public/login.html';
        }
      }
      
      // Ajout de l'URL de redirection pour revenir après connexion
      const returnUrl = encodeURIComponent(window.location.href);
      const separator = loginPath.includes('?') ? '&' : '?';
      const finalPath = `${loginPath}${separator}redirect=${returnUrl}`;
      
      // Redirection vers la page de connexion
      window.location.href = finalPath;
      return null;
    }
    
    return user;
  } catch (error) {
    console.error('Erreur lors de la vérification de l\'authentification:', error);
    
    // En cas d'erreur, redirection vers login par sécurité
    let loginPath = redirectPath || '../../public/login.html';
    window.location.href = loginPath;
    return null;
  }
}

/**
 * Vérifie l'authentification sans redirection (pour affichage conditionnel)
 * @returns {Promise<Object|null>} L'utilisateur connecté ou null
 */
export async function checkAuth() {
  try {
    return await authService.getCurrentUser();
  } catch (error) {
    console.error('Erreur lors de la vérification de l\'authentification:', error);
    return null;
  }
}

