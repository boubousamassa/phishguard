# 🐋 Guide Docker - 4students-NovaX

## Installation pour votre équipe

### Prérequis
1. Installer [Docker Desktop](https://www.docker.com/products/docker-desktop/)
2. Lancer Docker Desktop (il doit tourner en arrière-plan)

### Étapes pour lancer le projet

```bash
# 1. Cloner le projet
git clone [URL_DU_REPO]
cd 4students-NovaX

# 2. Configurer Supabase
cp src/config/config.json.example src/config/config.json
# Ouvrir src/config/config.json et ajouter vos clés Supabase

# 3. Démarrer le projet avec Docker
docker-compose up -d

# 4. Accéder à l'application
# Ouvrir le navigateur : http://localhost:8080
```

### Commandes utiles

```bash
# Démarrer le projet
docker-compose up -d

# Voir les logs
docker-compose logs -f

# Arrêter le projet
docker-compose down

# Rebuild (si vous modifiez le Dockerfile)
docker-compose up -d --build

# Accéder au terminal du conteneur
docker exec -it 4students-novax sh
```

### Problèmes courants

**Le port 8080 est déjà utilisé ?**
- Modifiez le port dans `docker-compose.yml` : `"3000:8080"` au lieu de `"8080:8080"`
- Accédez ensuite à `http://localhost:3000`

**Erreur Supabase ?**
- Vérifiez que `src/config/config.json` existe et contient les bonnes clés
- Ce fichier n'est pas versionné dans Git (pour la sécurité)

**Les modifications ne se voient pas ?**
- Les fichiers dans `/src` et `/public` sont synchronisés en temps réel
- Rafraîchissez simplement votre navigateur (Ctrl+F5)

## Pour les développeurs

Les volumes Docker synchronisent automatiquement vos modifications :
- `./src` → `/app/src`
- `./public` → `/app/public`
- `./node_modules` → `/app/node_modules`

Pas besoin de rebuild à chaque modification ! 🎉

